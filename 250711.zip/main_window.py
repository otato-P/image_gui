from PyQt5.QtWidgets import QWidget, QVBoxLayout, QPushButton, QFileDialog,QLabel,QLineEdit,QHBoxLayout
from ui_components.image_canvas import ImageCanvas
from image_processing.gaussian import asymmetric_gaussian_fwhm
import config
import cv2
from PyQt5.QtWidgets import (
    QMainWindow, QWidget, QLabel, QPushButton, QLineEdit,
    QVBoxLayout, QHBoxLayout, QGridLayout,QDesktopWidget
)

class MainWindow(QMainWindow):
    def __init__(self,roi_manager):
        super().__init__()
        self.setWindowTitle("图像处理工具")
        # self.resize(1280, 900)
        screen = QDesktopWidget().screenGeometry()
        self.resize(int(screen.width() * 0.5), int(screen.height() * 0.88))


        self.roi_manager = roi_manager

        #UI部件
        self.imageCanvas = ImageCanvas(self.roi_manager)
        self.imageCanvas.setMinimumSize(640, 480)

        self.loadButton = QPushButton("加载图像")
        self.plotAllButton = QPushButton("绘制全部拟合图")
        self.saveButton = QPushButton("保存拟合结果")
        self.toggleModeButton = QPushButton("切换模式")  # 框选ROI还是画线

        #信号连接
        self.loadButton.clicked.connect(self.loadImage)
        self.plotAllButton.clicked.connect(self.plotAllFits)
        self.saveButton.clicked.connect(self.saveResults)

        #按钮&输出框
        self.gaussianFitButton=QPushButton("高斯拟合 FWHM")
        self.directFitButton=QPushButton("直接拟合 FWHM")
        self.gaussianFitButton.clicked.connect(self.runGaussianFit)
        self.directFitButton.clicked.connect(self.runDirectFit)

        #输出框
        self.fwhmLeftOutput_g = QLineEdit(self)
        self.fwhmRightOutput_g = QLineEdit(self)
        self.sigmaOutput_g = QLineEdit(self)
        self.fwhmLeftOutput_d = QLineEdit(self)
        self.fwhmRightOutput_d = QLineEdit(self)
        self.sigmaOutput_d = QLineEdit(self)
        for box in (self.fwhmLeftOutput_g, self.fwhmRightOutput_g, self.sigmaOutput_g,self.fwhmLeftOutput_d, self.fwhmRightOutput_d, self.sigmaOutput_d):
            box.setFixedWidth(120)
            box.setReadOnly(True)
        
        # Add a QLineEdit for ratio input and a button to apply it
        self.ratio_input = QLineEdit(self)
        self.ratio_input.setText("0.6")  # Default ratio value
        self.ratio_input.setFixedWidth(120)
        
        self.apply_ratio_button = QPushButton("应用 Ratio", self)
        self.apply_ratio_button.clicked.connect(self.apply_ratio)

        sRatioLayout=QHBoxLayout()
        sRatioLayout.addWidget(self.ratio_input)
        sRatioLayout.addWidget(self.apply_ratio_button)
        RatioLayout = QVBoxLayout()
        RatioLayout.addWidget(QLabel("输入 Ratio (0-1)"))
        RatioLayout.addLayout(sRatioLayout)

         #输出区域
        outputBox = QVBoxLayout()
        outputBox.addWidget(self.loadButton)
        outputBox.addWidget(self.plotAllButton)
        outputBox.addWidget(self.saveButton)
        #outputBox.addWidget(self.toggleModeButton)
        outputBox.addLayout(RatioLayout)

        GaussianBox = QVBoxLayout()
        GaussianBox.addWidget(QLabel("高斯拟合FWHM 左"))
        GaussianBox.addWidget(self.fwhmLeftOutput_g)
        GaussianBox.addWidget(QLabel("高斯拟合FWHM 右"))
        GaussianBox.addWidget(self.fwhmRightOutput_g)
        GaussianBox.addWidget(QLabel("高斯拟合σ"))
        GaussianBox.addWidget(self.sigmaOutput_g)

        GaussianBox.setSpacing(15)
        GaussianBox.setContentsMargins(15, 15, 15, 15)

        DirectBox=QVBoxLayout()
        DirectBox.addWidget(QLabel("直接FWHM 左"))
        DirectBox.addWidget(self.fwhmLeftOutput_d)
        DirectBox.addWidget(QLabel("直接FWHM 右"))
        DirectBox.addWidget(self.fwhmRightOutput_d)
        DirectBox.addWidget(QLabel("直接σ"))
        DirectBox.addWidget(self.sigmaOutput_d)

        # inputLayout.setSpacing(10)  # 控件间距
        # inputLayout.setContentsMargins(10, 10, 10, 10)  # 设置外边距

        DirectBox.setSpacing(15)
        DirectBox.setContentsMargins(15, 15, 15, 15)

        fitBOX=QHBoxLayout()
        fitBOX.addLayout(GaussianBox)
        fitBOX.addLayout(DirectBox)

        outputBox.addLayout(fitBOX)

        #和按钮布局
        buttonLayout=QHBoxLayout()
        buttonLayout.addWidget(self.gaussianFitButton)
        buttonLayout.addWidget(self.directFitButton)
        outputBox.addLayout(buttonLayout)

        #图像部分
        imageLayout=QHBoxLayout()     
        outputBox.addWidget(self.imageCanvas,stretch=3)
        #self.setLayout(layout)
        #imageLayout.addWidget(self.imageLabel, stretch=3)     # 图像宽占 75%
        imageLayout.addLayout(outputBox, stretch=1)           # 输出宽占 25%

        #总布局
        # mainLayout = QVBoxLayout()
        # #mainLayout.addLayout(buttonLayout)   # 顶部按钮
        # mainLayout.addLayout(imageLayout)    # 图像 + 输出

        centralWidget = QWidget()
        centralWidget.setLayout(imageLayout)
        self.setCentralWidget(centralWidget)

        #self.mode = 'Parallel Lines'  # 默认模式为框选ROI

    def apply_ratio(self):
        try:
            config.ratio = float(self.ratio_input.text())
            if config.ratio < 0 or config.ratio > 1:
                raise ValueError("Ratio must be between 0 and 1.")
            print(f"[DEBUG] Applying Ratio: {config.ratio}")

        except ValueError as e:
            print(f"[ERROR] Invalid input: {e}")

    def runGaussianFit(self):
        result = self.imageCanvas.processSelectedRegionFit(mode="gaussian")
        if result:
            self.fwhmLeftOutput_g.setText(f"{result['fwhm_left']:.2f}")
            self.fwhmRightOutput_g.setText(f"{result['fwhm_right']:.2f}")
            self.sigmaOutput_g.setText(f"{result['sigma']:.6f}")
        else:
            self.fwhmLeftOutput_d.setText("计算失败")
            self.fwhmRightOutput_d.setText("计算失败")
            self.sigmaOutput_d.setText("计算失败")

    def runDirectFit(self):
        result = self.imageCanvas.processSelectedRegionFit(mode="direct")
        if result:
            self.fwhmLeftOutput_d.setText(f"{result['fwhm_left']:.2f}")
            self.fwhmRightOutput_d.setText(f"{result['fwhm_right']:.2f}")
            self.sigmaOutput_d.setText(f"{result['sigma']:.6f}")
        else:
            self.fwhmLeftOutput_d.setText("计算失败")
            self.fwhmRightOutput_d.setText("计算失败")
            self.sigmaOutput_d.setText("计算失败")


    def loadImage(self):
        filename, _ = QFileDialog.getOpenFileName(self, "选择图像", "", "Images (*.png *.jpg *.bmp *.tif)")
        if filename:
            image = cv2.imread(filename)
            self.imageCanvas.setImage(image,filename)
            self.imageCanvas.current_filename = filename  # 可选：存储当前图片文件名

    def plotAllFits(self):
        self.roi_manager.plot_all_fits()

    def saveResults(self):
        save_path, _ = QFileDialog.getSaveFileName(self, "保存结果", "results.json", "JSON Files (*.json)")
        if save_path:
            self.roi_manager.save_to_json(save_path)