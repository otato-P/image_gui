from PyQt5.QtWidgets import QApplication
import sys
from main_window import MainWindow
import os
from image_processing.roi_data_manager import ROIDataManager
from image_processing.roi_result import ROIResult

sys.path.append(os.path.dirname(__file__))  # 把 RHEED 加入 sys.path

def main():
    app = QApplication(sys.argv)

    # 创建 ROI 数据管理器
    roi_manager = ROIDataManager()

    window = MainWindow(roi_manager)
    window.show()
    sys.exit(app.exec_())


if __name__ == "__main__":
    main()


