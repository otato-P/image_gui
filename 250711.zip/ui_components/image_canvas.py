from PyQt5.QtWidgets import QLabel
from PyQt5.QtGui import QImage, QPixmap, QPainter, QPen
from PyQt5.QtCore import Qt, QRect
import cv2
import numpy as np
from os.path import basename
from image_processing.roi_fitting import fit_roi_data
from image_processing.roi_fitting import fit_roi_data_direct
from image_processing import roi_fitting
from image_processing.roi_result import ROIResult
from image_processing.peak_analysis import calculate_peak_distance
from image_processing.calculate import calculate_screen_distance
import config
from image_processing.fwhm_analysis import calculate_fwhm_from_profile,compute_fwhm_and_sigma
from PyQt5.QtWidgets import QSizePolicy


from os.path import basename
class ImageCanvas(QLabel):
    def __init__(self, roi_manager=None):
        super().__init__()
        self.roi_manager = roi_manager
        self.image = None
        self.current_filename = None
        self.start = None
        self.end = None
        self.rect = None
        self.drawing = False
        self.mode = 'ROI'
        #self.mode = 'Parallel Lines'
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)

        self.scale_x = 1
        self.scale_y = 1
        self.offset_x = 0
        self.offset_y = 0
        self.scaled_pixmap = None

        self.profile_data = None  # 初始化 profile_data 属性

    def setMode(self, mode):
        # 切换模式
        self.mode = mode
        print(f"Current mode: {self.mode}")

    def setImage(self, image, filename=None):
        self.image = image
        self.current_filename = filename

        qimage = self.convertToQImage(image)
        pixmap = QPixmap.fromImage(qimage)

        # 缩放图片到控件大小，保持比例
        #scaled_pixmap = pixmap.scaled(self.size(), Qt.KeepAspectRatio, Qt.SmoothTransformation)
        self.scaled_pixmap = pixmap.scaled(self.size(), Qt.KeepAspectRatioByExpanding, Qt.SmoothTransformation)
        
        self.setPixmap(self.scaled_pixmap)

        # 记录缩放比例
        self.scale_x = image.shape[1] / self.scaled_pixmap.width()
        self.scale_y = image.shape[0] / self.scaled_pixmap.height()
        # 记录偏移（如果图像居中显示，会有边距）
        self.offset_x = (self.width() - self.scaled_pixmap.width()) // 2
        self.offset_y = (self.height() - self.scaled_pixmap.height()) // 2

        self.start = self.end = self.rect = None

        print(f"[DEBUG] 图像大小: {image.shape[1]}x{image.shape[0]}")
        print(f"[DEBUG] scaled_pixmap大小: {self.scaled_pixmap.width()}x{self.scaled_pixmap.height()}")
        print(f"[DEBUG] scale_x={self.scale_x:.3f}")


    def resizeEvent(self, event):
        self.updatePixmap()
        super().resizeEvent(event)
        if hasattr(self, 'image') and self.image is not None:
            self.setImage(self.image, self.current_filename)

    #界面坐标转为原图坐标
    # def mapToOriginal(self, point):
    #     x = (point.x() - self.offset_x) * self.scale_x
    #     y = (point.y() - self.offset_y) * self.scale_y
    #     return int(x), int(y)
    def mapToOriginal(self, point):
        x = point.x() - self.offset_x
        y = point.y() - self.offset_y

        x = max(0, min(x, self.pixmap().width()))
        y = max(0, min(y, self.pixmap().height()))

        return int(x * self.scale_x), int(y * self.scale_y)



    def updatePixmap(self):
        # if self.scaled_pixmap:
        #     self.setPixmap(self.scaled_pixmap)
        if self.image is None:
            return
        qimage = self.convertToQImage(self.image)
        pixmap = QPixmap.fromImage(qimage)
        #scaled_pixmap = pixmap.scaled(self.size(), Qt.KeepAspectRatio, Qt.SmoothTransformation)
        self.scaled_pixmap = pixmap.scaled(self.size(), Qt.KeepAspectRatioByExpanding, Qt.SmoothTransformation) 
        self.setPixmap(self.scaled_pixmap)
        # 重新计算比例和偏移，保证映射准确
        self.scale_x = self.image.shape[1] / self.scaled_pixmap.width()
        self.scale_y = self.image.shape[0] / self.scaled_pixmap.height()
        self.offset_x = (self.width() - self.scaled_pixmap.width()) // 2
        self.offset_y = (self.height() - self.scaled_pixmap.height()) // 2

    def resizeEvent(self, event):
        self.updatePixmap()
        super().resizeEvent(event)

    def convertToQImage(self, image):
        height, width, channels = image.shape
        bytes_per_line = channels * width
        return QImage(image.data, width, height, bytes_per_line, QImage.Format_BGR888)

    def mousePressEvent(self, event):
        if event.button() == Qt.LeftButton:
            self.start = event.pos()
            self.drawing = True

    def mouseMoveEvent(self, event):
        if self.drawing:
            self.end = event.pos()
            self.update()

    def mouseReleaseEvent(self, event):
        if event.button() == Qt.LeftButton and self.start and self.end:
            self.drawing = False
            self.rect = QRect(self.start, self.end).normalized()
            self.updatePixmap()  # ✅ 强制同步缩放图和比例

            if self.mode == 'ROI':
                print("[DEBUG] 框选完毕，等待按钮执行拟合")
            print("Mouse released, processing selected region.")
            self.processSelectedRegion()

    # def processSelectedRegion(self):
    #     if self.rect is None or self.image is None:
    #         print("未选择区域")
    #         return

    #     self.updatePixmap()  # 确保显示更新，但不修改 scale_x

    #     print(f"[DEBUG] 控件大小: {self.width()}x{self.height()}")
    #     print(f"[DEBUG] pixmap大小: {self.pixmap().width()}x{self.pixmap().height()}")
    #     print(f"[DEBUG] offset_x={self.offset_x}, offset_y={self.offset_y}")
    #     print(f"[DEBUG] scale_x={self.scale_x:.3f}, scale_y={self.scale_y:.3f}")
    #     print(f"[DEBUG] 起点坐标: {self.start.x()}, {self.start.y()}")
    #     print(f"[DEBUG] 映射后: {self.mapToOriginal(self.start)}")

    #     # 将界面坐标映射为原图坐标
    #     x1, y1 = self.mapToOriginal(self.rect.topLeft())
    #     x2, y2 = self.mapToOriginal(self.rect.bottomRight())

    #     x1, x2 = sorted([max(0, min(self.image.shape[1] - 1, x1)), max(0, min(self.image.shape[1] - 1, x2))])
    #     y1, y2 = sorted([max(0, min(self.image.shape[0] - 1, y1)), max(0, min(self.image.shape[0] - 1, y2))])
    #     print(f"[DEBUG] Selected region (original image coordinates): x1={x1}, y1={y1}, x2={x2}, y2={y2}")


    #     # 获取ROI的水平长度（x方向上的宽度）
    #     roi_width = abs(x2 - x1)

    #     # 如果水平长度大于500，则返回这个水平长度
    #     if roi_width > 400:
    #         config.screen_length=roi_width

    #         # 在这里进行 ROI 的相关操作，例如提取图像数据、保存、绘制等
    #         #print(f"ROI 坐标: ({x1}, {y1}) 到 ({x2}, {y2})")
    #         print(f"荧光屏宽度: ({config.screen_length})")
        
    #     roi = self.image[y1:y2, x1:x2]
    #     print(f"[DEBUG] ROI shape: {roi.shape}")

    #     if roi.size == 0 or roi.shape[0] == 0 or roi.shape[1] == 0:
    #         print("[ERROR] 空 ROI，跳过处理")
    #         return

    #     # ✅ 可视化查看选中的 ROI（调试用）
    #     import matplotlib.pyplot as plt
    #     plt.imshow(cv2.cvtColor(roi, cv2.COLOR_BGR2RGB))
    #     plt.title("Selected ROI")
    #     plt.show()

    #     # 灰度分析 & 拟合
    #     result = fit_roi_data(roi)
    #     if not result:
    #         print("[ERROR] ROI 拟合失败")
    #         return

    #     profile = result.get('profile', [])
    #     smooth_profile = result.get('smooth_profile', None)
    #     peaks = result.get('peaks', [])
    #     peak_values = result.get('peak_values', [])

    #     fwhm = calculate_peak_distance(peaks, peak_values, profile)

    #     if self.roi_manager and self.current_filename and profile is not None:
    #         roi_result = ROIResult(
    #             coords=(x1, y1, x2, y2),
    #             mean_values=profile,
    #             slope=peak_values[0] if len(peak_values) > 0 else 0,
    #             intercept=0,
    #             smooth_profile=smooth_profile,
    #             peaks=peaks,
    #             axis=result.get('axis')
    #         )
    #         self.roi_manager.add_result(
    #             image_name=basename(self.current_filename),
    #             roi_result=roi_result
    #         )
    def processSelectedRegion(self):
        if self.rect is None or self.image is None:
            print("未选择区域")
            return

        self.updatePixmap()  # 确保显示更新，但不修改 scale_x

        # 打印调试信息
        print(f"[DEBUG] 控件大小: {self.width()}x{self.height()}")
        print(f"[DEBUG] pixmap大小: {self.pixmap().width()}x{self.pixmap().height()}")
        print(f"[DEBUG] offset_x={self.offset_x}, offset_y={self.offset_y}")
        print(f"[DEBUG] scale_x={self.scale_x:.3f}, scale_y={self.scale_y:.3f}")
        print(f"[DEBUG] 起点坐标: {self.start.x()}, {self.start.y()}")
        print(f"[DEBUG] 映射后: {self.mapToOriginal(self.start)}")

        # 将界面坐标映射为原图坐标
        x1, y1 = self.mapToOriginal(self.rect.topLeft())
        x2, y2 = self.mapToOriginal(self.rect.bottomRight())

        # 确保坐标合法
        x1, x2 = sorted([max(0, min(self.image.shape[1] - 1, x1)), max(0, min(self.image.shape[1] - 1, x2))])
        y1, y2 = sorted([max(0, min(self.image.shape[0] - 1, y1)), max(0, min(self.image.shape[0] - 1, y2))])
        print(f"[DEBUG] Selected region (original image coordinates): x1={x1}, y1={y1}, x2={x2}, y2={y2}")

        # 获取ROI的水平长度（x方向上的宽度）
        roi_width = abs(x2 - x1)

        # 如果水平长度大于400，则返回这个水平长度
        if roi_width > 400:
            config.screen_length = roi_width
            print(f"荧光屏宽度: ({config.screen_length})")

        # 提取 ROI 区域
        roi = self.image[y1:y2, x1:x2]
        print(f"[DEBUG] ROI shape: {roi.shape}")

        # 检查ROI是否为空
        if roi.size == 0 or roi.shape[0] == 0 or roi.shape[1] == 0:
            print("[ERROR] 空 ROI，跳过处理")
            return

        # 可视化查看选中的 ROI（调试用）
        import matplotlib.pyplot as plt
        plt.imshow(cv2.cvtColor(roi, cv2.COLOR_BGR2RGB))
        plt.title("Selected ROI")
        plt.show()

        # 将 ROI 数据存储在 profile_data 中
        self.profile_data = np.mean(roi, axis=0)  # 如果需要按列处理

        # 灰度分析 & 拟合
        result = fit_roi_data(roi)
        if not result:
            print("[ERROR] ROI 拟合失败")
            return

        profile = result.get('profile', [])
        smooth_profile = result.get('smooth_profile', None)
        peaks = result.get('peaks', [])
        peak_values = result.get('peak_values', [])

        # 计算峰值距离 FWHM
        fwhm = calculate_peak_distance(peaks, peak_values, profile)

        # 如果 roi_manager 存在且 profile 不为空，保存结果
        if self.roi_manager and self.current_filename and profile is not None:
            roi_result = ROIResult(
                coords=(x1, y1, x2, y2),
                mean_values=profile,
                slope=peak_values[0] if len(peak_values) > 0 else 0,
                intercept=0,
                smooth_profile=smooth_profile,
                peaks=peaks,
                axis=result.get('axis')
            )
            self.roi_manager.add_result(
                image_name=basename(self.current_filename),
                roi_result=roi_result
            )


        # if self.rect and self.image is not None:
        #     x1, y1 = self.mapToOriginal(self.rect.topLeft())
        #     x2, y2 = self.mapToOriginal(self.rect.bottomRight())

        #     x1 = max(0, min(self.image.shape[1] - 1, x1))
        #     x2 = max(0, min(self.image.shape[1] - 1, x2))
        #     y1 = max(0, min(self.image.shape[0] - 1, y1))
        #     y2 = max(0, min(self.image.shape[0] - 1, y2))

        #     if x1 > x2:
        #         x1, x2 = x2, x1
        #     if y1 > y2:
        #         y1, y2 = y2, y1

        #     print(f"Selected region: x1={x1}, y1={y1}, x2={x2}, y2={y2}")

        #     image = self.image
        #     roi = self.image[y1:y2, x1:x2]
        #     print(f"ROI shape: {roi.shape}")

        #     #fit_roi_data(roi)
        #     if roi.size == 0 or roi.shape[0] == 0 or roi.shape[1] == 0:
        #         print("Empty ROI, skipping processing.")
        #         return

        #     result = fit_roi_data(roi)  # 直接接收字典
        #     print("Fit result dict:", result)


        #     mean_vals = result.get('profile', [])  # 你想用字典里哪个字段，就取哪个，比如 profile 曲线数据
        #     #fit_result = result.get('peaks', [])
        #     fit_result = result.get('smooth_profile', None)  # 假设是拟合结果字段

        #     peaks = result.get('peaks', [])
        #     peak_values = result.get('peak_values', [])
        #     profile = result.get('profile', [])  # 确保获取了profile数据

        #     # 调用提取峰值信息的函数
        #     peak_distance = calculate_peak_distance(peaks, peak_values,profile)

        #     if self.roi_manager and self.current_filename and mean_vals is not None and fit_result is not None:
        #         roi_result = ROIResult(
        #             #image_name=basename(self.current_filename),
        #             coords=(x1, y1, x2, y2),
        #             mean_values=mean_vals,
        #             slope=result['peak_values'][0] if result['peak_values'].size > 0 else 0,  # 使用峰值作为示例
        #             intercept=0,  # 可以根据需要计算截距
        #             smooth_profile=result.get('smooth_profile'),
        #             peaks=result.get('peaks'),
        #             axis=result.get('axis')
        #             #coeffs=coeffs
        #         )
        #         self.roi_manager.add_result(
        #             image_name=basename(self.current_filename),
        #             roi_result=roi_result
        #         )


    def paintEvent(self, event):
        super().paintEvent(event)
        if self.start and self.end:
        #if self.start and self.end and self.drawing:
            painter = QPainter(self)
            painter.setPen(QPen(Qt.red, 2, Qt.DashLine))
            painter.drawRect(QRect(self.start, self.end))


    def processSelectedRegionFit(self, mode="gaussian"):
        print(f"[DEBUG]正在运行模式:{mode}")

        if self.rect is None or self.image is None:
            print("未选择ROI")
            return None

        x1, y1 = self.mapToOriginal(self.rect.topLeft())
        x2, y2 = self.mapToOriginal(self.rect.bottomRight())

        x1, x2 = sorted([max(0, min(self.image.shape[1] - 1, x1)),
                        max(0, min(self.image.shape[1] - 1, x2))])
        y1, y2 = sorted([max(0, min(self.image.shape[0] - 1, y1)),
                        max(0, min(self.image.shape[0] - 1, y2))])

        roi = self.image[y1:y2, x1:x2]
        if roi.size == 0:
            print("空ROI")
            return None

        # 处理模式
        if mode == "gaussian":
            result = fit_roi_data(roi)
            
        elif mode == "direct":
            #from image_processing.direct_fwhm import estimate_fwhm_geometrically, plot_direct_fwhm
            result = fit_roi_data_direct(roi)
        else:
            return None

        if not result:
            print("拟合失败")
            return None

        profile = result.get('profile', [])
        peaks = result.get('peaks', [])
        peak_values = result.get('peak_values', [])

        if profile is None or peaks is None or len(peaks)==0 or len(profile)==0:
            print("无有效 profile 或 peaks")
            return None
        # # 使用统一接口计算 FWHM 和 σ
        # use_gaussian = (mode == "gaussian")
        # plot = not use_gaussian  # 只有 direct 时才画图
        # peak_x = int(peaks[0])
        # fwhm_l, fwhm_r, sigma = compute_fwhm_and_sigma(profile, peak_x, use_gaussian=use_gaussian, plot=plot)

        peak_x = int(round(peaks[0]))

        # if mode == "gaussian":
        #     # 保留原有通用函数调用
        #     from image_processing.fwhm_analysis import compute_fwhm_and_sigma
        #     fwhm_l, fwhm_r, sigma = compute_fwhm_and_sigma(profile, peak_x, use_gaussian=True, plot=False)
        # else:
        #     # 使用三次样条 & 背底修正计算 FWHM
        #     fwhm_l, fwhm_r, baseline, y_spline, y_adjusted, half_max = estimate_fwhm_geometrically(
        #         profile, peak_x, fraction=0.7
        #     )
        #     plot_direct_fwhm(profile, peak_x, fwhm_l, fwhm_r, baseline, y_spline, y_adjusted, half_max, fraction=0.7)
        #     sigma = 0  # 或根据需要设为 None
        from image_processing.fwhm_analysis import compute_fwhm_and_sigma
        use_gaussian = (mode == "gaussian")
        fwhm_l, fwhm_r, c_ratio,sigma = compute_fwhm_and_sigma(
            profile, peak_x,
            use_gaussian=use_gaussian,
            plot=not use_gaussian  # 仅 direct 时绘图
    )

        print(f"[DEBUG] 模式: {mode}")
        print(f"[DEBUG] FWHM 左={fwhm_l:.2f}, 右={fwhm_r:.2f}")
        print(f"[DEBUG] σ 值为: {sigma:.6f}")

        return {
            "fwhm_left": fwhm_l,
            "fwhm_right": fwhm_r,
            "ratio":c_ratio,
            "sigma": sigma

        }
    
 



