from scipy.optimize import curve_fit
from scipy.interpolate import CubicSpline
import numpy as np
import matplotlib.pyplot as plt
from scipy.interpolate import interp1d
def gaussian(x, a, x0, sigma, offset):
    return a * np.exp(-(x - x0) ** 2 / (2 * sigma ** 2)) + offset

# def compute_half_max(profile, peak_x):
#     baseline = np.min(profile)
#     peak_val = profile[peak_x]
#     return baseline + (peak_val - baseline) / 2
# 修改 compute_half_max，增加 ratio 参数
def compute_half_max(profile, peak_x, ratio=0.5):
    baseline = np.min(profile)
    peak_val = profile[peak_x]
    return baseline + (peak_val - baseline) * ratio


def estimate_fwhm_right_geometrically(profile, peak_x):
    y = profile
    x = np.arange(len(y))
    half_max = compute_half_max(y, peak_x)

    right_half = y[peak_x:]
    below = np.where(right_half < half_max)[0]

    if below.size < 1 or (peak_x + below[0] + 1 >= len(y)):
        return 0

    idx1 = below[0]
    x_vals = x[peak_x + idx1 - 1: peak_x + idx1 + 1]
    y_vals = y[peak_x + idx1 - 1: peak_x + idx1 + 1]

    try:
        f_interp = interp1d(y_vals, x_vals)
        x_cross = f_interp(half_max)
        return x_cross - peak_x
    except Exception:
        return 0

def estimate_fwhm_left_geometrically(profile, peak_x):
    y = profile
    x = np.arange(len(y))
    half_max = compute_half_max(y, peak_x)

    left_half = y[:peak_x + 1][::-1]  # 从峰左侧往回看
    below = np.where(left_half < half_max)[0]

    if below.size < 1 or (peak_x - below[0] - 1 < 0):
        return 0

    idx1 = below[0]
    i1 = peak_x - idx1 + 1
    x_vals = x[i1 - 1: i1 + 1]
    y_vals = y[i1 - 1: i1 + 1]

    try:
        f_interp = interp1d(y_vals, x_vals)
        x_cross = f_interp(half_max)
        return peak_x - x_cross
    except Exception:
        return 0

from scipy.signal import savgol_filter
# def asymmetric_gaussian_fwhm(profile, peak_x
#                              #, window_size
                        
#                              ):
    
#     x = np.arange(len(profile))
#     y = profile
#     #y = savgol_filter(profile, window_length=9, polyorder=3)

#     # ⛳ 修正 peak_x 若非真实峰值
#     if y[peak_x] < np.max(y):
#         peak_x = int(np.argmax(y))
    
#     # 自动估计左右窗口
#     est_left = int(estimate_fwhm_left_geometrically(y, peak_x)) or 15
#     est_right = int(estimate_fwhm_right_geometrically(y, peak_x)) or 15

#     window_size_left = max(10, min(est_left * 2, 50))
#     window_size_right = max(10, min(est_right * 2, 50))

#     #左侧初始化
#     x_left = x[max(0, peak_x - window_size_left ):peak_x + 1]
#     y_left = y[max(0, peak_x - window_size_left ):peak_x + 1]
#     baseline_left = np.min(y_left)
#     a_left = np.max(y_left) - baseline_left
#     x0_left = x_left[np.argmax(y_left)]
#     sigma_left = max(len(x_left) / 5, 2)

#     try:
#         popt_left, _ = curve_fit(
#             gaussian, x_left, y_left,
#             p0=[a_left, x0_left, sigma_left, baseline_left],
#             #bounds=([0, x0_guess - est_left, 1, 0], [np.inf, x0_guess + 1, 50, np.max(y)]),
#             bounds=([0, x_left[0], 1, 0], [np.inf, x_left[-1], 50, np.max(y_left)]),
#             maxfev=5000
#         )
#         fwhm_left = 2.355 * abs(popt_left[2])
#         fit_left = gaussian(x_left, *popt_left)
#     except Exception as e:
#         print("左半高斯拟合失败:", e)
#         fwhm_left = 0
#         fit_left = np.zeros_like(x_left)

#     #右侧初始化
#     x_right = x[peak_x: min(len(x), peak_x + window_size_right)]
#     y_right = y[peak_x: min(len(y), peak_x + window_size_right)]
#     baseline_right = np.min(y_right)
#     a_right = np.max(y_right) - baseline_right
#     x0_right = x_right[np.argmax(y_right)]
#     sigma_right = max(len(x_right) / 5, 2)

#     try:
#         popt_right, _ = curve_fit(
#             gaussian, x_right, y_right,
#             p0=[a_right, x0_right, sigma_right, baseline_right],
#             #bounds=([0, x0_guess, 1, 0], [np.inf, x0_guess + est_right, 50, np.max(y)]),
#             bounds=([0, x_right[0], 1, 0], [np.inf, x_right[-1], 50, np.max(y_right)]),
#             maxfev=5000
#         )
#         fwhm_right = 2.355 * abs(popt_right[2])
#         fit_right = gaussian(x_right, *popt_right)
#     except Exception as e:
#         print("右半高斯拟合失败:", e)
#         # fwhm_right = estimate_fwhm_right_geometrically(y, peak_x)
#         fwhm_right=0
#         fit_right = np.zeros_like(x_right)
#         # popt_right=[0,0,0,0]
#         # right_used_fallback = True


#     fwhm_total = (fwhm_left + fwhm_right) / 2 if (fwhm_left > 0 and fwhm_right > 0) else max(fwhm_left, fwhm_right)

#     # ✅ 可视化
#     plt.figure(figsize=(10, 4))
#     plt.plot(x, y, label='原始 Profile', color='black')
#     plt.plot(x_left, fit_left, '--', label='左半高斯拟合', color='blue')
#     plt.plot(x_right, fit_right, '--', label='右半高斯拟合' ,#+ (' (fallback)' if right_used_fallback else ''),
#              color='red')
#     plt.axvline(peak_x, linestyle=':', color='gray', label='峰位置')

#     plt.title(f'左右半高斯拟合（FWHM: {fwhm_total:.2f}）')
#     plt.xlabel('像素位置')
#     plt.ylabel('灰度值')
#     plt.legend()
#     plt.tight_layout()
#     plt.show()

#     # 中心峰位置
#     plt.axvline(peak_x, linestyle=':', color='gray', label='峰位置')

#  # 左侧半高线
#     half_y_left = popt_left[3] + popt_left[0] / 2
#     idx_left = np.argmin(np.abs(fit_left - half_y_left))
#     x_half_left = x_left[idx_left]
#     plt.axvline(x_half_left, linestyle=':', color='blue', label='左半高宽位置')
#     plt.axhline(half_y_left, linestyle='--', color='blue', alpha=0.5)
#     plt.text(x_half_left, half_y_left + 2, f"{x_half_left:.1f}", color='blue')

#     # 右侧半高线
#     half_y_right = popt_right[3] + popt_right[0] / 2
#     idx_right = np.argmin(np.abs(fit_right - half_y_right))
#     x_half_right = x_right[idx_right]
#     plt.axvline(x_half_right, linestyle=':', color='red', label='右半高宽位置')
#     plt.axhline(half_y_right, linestyle='--', color='red', alpha=0.5)
#     plt.text(x_half_right, half_y_right + 2, f"{x_half_right:.1f}", color='red')

#     print(f"[非对称高斯拟合] FWHM 左={fwhm_left:.2f}, 右={fwhm_right:.2f}, 合并={fwhm_total:.2f}")
#     return fwhm_left, fwhm_right

# def compute_threshold(profile, peak_x, ratio=0.5):
#     baseline = np.min(profile)
#     peak_val = profile[peak_x]
    
#     return baseline + (peak_val - baseline) * ratio

#def asymmetric_gaussian_fwhm(profile, peak_x):
# def asymmetric_gaussian_fwhm(profile, peak_x,ratio=0.4,max_fit_len=30):
 
#     x = np.arange(len(profile))
#     y = profile

#     # ⛳ 修正 peak_x 若非真实峰值
#     if y[peak_x] < np.max(y):
#         peak_x = int(np.argmax(y))

#     # 使用 60% 高度作为拟合范围的界限
#     threshold = compute_threshold(y, peak_x, ratio=ratio)

#     # 左侧提取大于阈值的点
#     left_mask = (x < peak_x) & (y >= threshold)
#     left_indices = np.where(left_mask)[0][-max_fit_len:]  # 最多 max_fit_len 个点
#     x_left = x[left_indices]
#     y_left = y[left_indices]

#     # 右侧提取大于阈值的点
#     right_mask = (x > peak_x) & (y >= threshold)
#     right_indices = np.where(right_mask)[0][:max_fit_len]  # 最多 max_fit_len 个点
#     x_right = x[right_indices]
#     y_right = y[right_indices]

#     # # ➤ 左侧：从 peak_x 向左找第一个小于 threshold 的位置
#     # left_idx = peak_x
#     # while left_idx > 0 and y[left_idx] > threshold:
#     #     left_idx -= 1
#     # x_left = x[left_idx:peak_x + 1]
#     # y_left = y[left_idx:peak_x + 1]

#     # # ➤ 右侧：从 peak_x 向右找第一个小于 threshold 的位置
#     # right_idx = peak_x
#     # while right_idx < len(y) - 1 and y[right_idx] > threshold:
#     #     right_idx += 1
#     # x_right = x[peak_x:right_idx + 1]
#     # y_right = y[peak_x:right_idx + 1]

#     # # 左侧拟合
#     # baseline_left = np.min(y_left)
#     # a_left = np.max(y_left) - baseline_left
#     # x0_left = x_left[np.argmax(y_left)]
#     # sigma_left = max(len(x_left) / 5, 2)

#     # 左拟合
#     try:
#         baseline_left = np.min(y_left)
#         a_left = np.max(y_left) - baseline_left
#         x0_left = x_left[np.argmax(y_left)]
#         sigma_left = max(len(x_left) / 5, 1)
#         popt_left, _ = curve_fit(gaussian, x_left, y_left,
#                                  p0=[a_left, x0_left, sigma_left, baseline_left],
#                                  bounds=([0, x_left[0], 0.1, 0], [np.inf, x_left[-1], 50, np.max(y_left)]),
#                                  maxfev=5000)
#         fit_left = gaussian(x_left, *popt_left)
#         fwhm_left = 2.355 * abs(popt_left[2])
#     except Exception as e:
#         print("❌ 左半拟合失败:", e)
#         fit_left = np.zeros_like(x_left)
#         fwhm_left = 0

#     # 右拟合
#     try:
#         baseline_right = np.min(y_right)
#         a_right = np.max(y_right) - baseline_right
#         x0_right = x_right[np.argmax(y_right)]
#         sigma_right = max(len(x_right) / 5, 1)
#         popt_right, _ = curve_fit(gaussian, x_right, y_right,
#                                   p0=[a_right, x0_right, sigma_right, baseline_right],
#                                   bounds=([0, x_right[0], 0.1, 0], [np.inf, x_right[-1], 50, np.max(y_right)]),
#                                   maxfev=5000)
#         fit_right = gaussian(x_right, *popt_right)
#         fwhm_right = 2.355 * abs(popt_right[2])
#     except Exception as e:
#         print("❌ 右半拟合失败:", e)
#         fit_right = np.zeros_like(x_right)
#         fwhm_right = 0


#     # try:
#     #     popt_left, _ = curve_fit(
#     #         gaussian, x_left, y_left,
#     #         p0=[a_left, x0_left, sigma_left, baseline_left],
#     #         bounds=([0, x_left[0], 1, 0], [np.inf, x_left[-1], 50, np.max(y_left)]),
#     #         maxfev=5000
#     #     )
#     #     fwhm_left = 2.355 * abs(popt_left[2])
#     #     fit_left = gaussian(x_left, *popt_left)
#     # except Exception as e:
#     #     print("左半高斯拟合失败:", e)
#     #     fwhm_left = 0
#     #     fit_left = np.zeros_like(x_left)

#     # # 右侧拟合
#     # baseline_right = np.min(y_right)
#     # a_right = np.max(y_right) - baseline_right
#     # x0_right = x_right[np.argmax(y_right)]
#     # sigma_right = max(len(x_right) / 5, 2)

#     # try:
#     #     popt_right, _ = curve_fit(
#     #         gaussian, x_right, y_right,
#     #         p0=[a_right, x0_right, sigma_right, baseline_right],
#     #         bounds=([0, x_right[0], 1, 0], [np.inf, x_right[-1], 50, np.max(y_right)]),
#     #         maxfev=5000
#     #     )
#     #     fwhm_right = 2.355 * abs(popt_right[2])
#     #     fit_right = gaussian(x_right, *popt_right)
#     # except Exception as e:
#     #     print("右半高斯拟合失败:", e)
#     #     fwhm_right = 0
#     #     fit_right = np.zeros_like(x_right)

#     fwhm_total = (fwhm_left + fwhm_right) / 2 if (fwhm_left > 0 and fwhm_right > 0) else max(fwhm_left, fwhm_right)
#     print(f"[DEBUG] peak_x = {peak_x}, threshold = {threshold:.2f}")
#     print(f"[DEBUG] 左侧拟合点数 = {len(left_indices)}，右侧拟合点数 = {len(right_indices)}")

#     # ✅ 可视化
#     plt.figure(figsize=(10, 5))
#     plt.plot(x, y, label='origin Profile', color='black')
#     plt.axhline(threshold, linestyle='--', color='purple', alpha=0.5, label=f'{int(ratio*100)}% 阈值')
#     plt.plot(x_left, y_left, color='blue', linewidth=2, label='Left 75% 数据')
#     plt.plot(x_right, y_right, color='red', linewidth=2, label='Right 75% 数据')

#     plt.plot(x_left, fit_left, '--', label='Left half Gaussian fitting', color='blue')
#     plt.plot(x_right, fit_right, '--', label='Right half Gaussian fitting', color='red')
#     plt.axvline(peak_x, linestyle=':', color='gray', label='峰位置')

#     if fwhm_left > 0:
#         y_half_l = popt_left[3] + popt_left[0] / 2
#         x_half_l = x_left[np.argmin(np.abs(fit_left - y_half_l))]
#         plt.axvline(x_half_l, linestyle=':', color='blue', label='左半高位置')
#         plt.axhline(y_half_l, linestyle=':', color='blue', alpha=0.4)

#     if fwhm_right > 0:
#         y_half_r = popt_right[3] + popt_right[0] / 2
#         x_half_r = x_right[np.argmin(np.abs(fit_right - y_half_r))]
#         plt.axvline(x_half_r, linestyle=':', color='red', label='右半高位置')
#         plt.axhline(y_half_r, linestyle=':', color='red', alpha=0.4)

#     # # 半高线标注
#     # if fwhm_left > 0:
#     #     half_y_left = popt_left[3] + popt_left[0] / 2
#     #     idx_left = np.argmin(np.abs(fit_left - half_y_left))
#     #     x_half_left = x_left[idx_left]
#     #     plt.axvline(x_half_left, linestyle=':', color='blue', label='Left half-with position')
#     #     plt.axhline(half_y_left, linestyle='--', color='blue', alpha=0.5)
#     #     plt.text(x_half_left, half_y_left + 2, f"{x_half_left:.1f}", color='blue')

#     # if fwhm_right > 0:
#     #     half_y_right = popt_right[3] + popt_right[0] / 2
#     #     idx_right = np.argmin(np.abs(fit_right - half_y_right))
#     #     x_half_right = x_right[idx_right]
#     #     plt.axvline(x_half_right, linestyle=':', color='red', label='Right half-with position')
#     #     plt.axhline(half_y_right, linestyle='--', color='red', alpha=0.5)
#     #     plt.text(x_half_right, half_y_right + 2, f"{x_half_right:.1f}", color='red')
#     plt.axvline(peak_x, linestyle=':', color='gray', label='峰中心')
#     plt.title(f'左右半高斯拟合（FWHM: {fwhm_total:.2f}）')
#     plt.xlabel('像素位置')
#     plt.ylabel('灰度值')
#     plt.legend()
#     plt.tight_layout()
#     plt.show()

#     print(f"[非对称高斯拟合] FWHM 左={fwhm_left:.2f}, 右={fwhm_right:.2f}, 合并={fwhm_total:.2f}")
#     return fwhm_left, fwhm_right


# def find_largest_continuous_segment(mask):
#     """
#     输入一个布尔数组，返回最长连续 True 的起止索引。
#     """
#     max_len = 0
#     max_range = (0, 0)
#     start = None
#     for i, val in enumerate(mask):
#         if val:
#             if start is None:
#                 start = i
#         else:
#             if start is not None:
#                 length = i - start
#                 if length > max_len:
#                     max_len = length
#                     max_range = (start, i - 1)
#                 start = None
#     # 处理最后一段连续 True
#     if start is not None:
#         length = len(mask) - start
#         if length > max_len:
#             max_range = (start, len(mask) - 1)
#     return max_range

# def gaussian_threshold_fit(profile, fraction=0.7, plot=True):
#     x = np.arange(len(profile))
#     y = profile

#     # 自动找峰值索引
#     peak_x = int(np.argmax(y))
#     baseline = np.min(y)
#     peak_val = y[peak_x]
#     threshold = baseline + (peak_val - baseline) * fraction

#     # 找出最大连续高于阈值区域
#     above_mask = y > threshold
#     seg_start, seg_end = find_largest_continuous_segment(above_mask)

#     if seg_end - seg_start < 5:
#         print("[警告] 拟合区太小")
#         return 0, 0, 0

#     x_fit = x[seg_start:seg_end+1]
#     y_fit = y[seg_start:seg_end+1]

#     # 高斯初值
#     a0 = np.max(y_fit) - baseline
#     x0 = x_fit[np.argmax(y_fit)]
#     sigma0 = len(x_fit) / 5
#     offset0 = baseline

#     try:
#         popt, _ = curve_fit(
#             gaussian, x_fit, y_fit,
#             p0=[a0, x0, sigma0, offset0],
#             bounds=([0, x_fit[0], 1, 0], [np.inf, x_fit[-1], 100, np.max(y_fit)])
#         )
#         fitted = gaussian(x_fit, *popt)
#         sigma = abs(popt[2])
#         fwhm = 2.355 * sigma
#         fwhm_left = popt[1] - x_fit[0]
#         fwhm_right = x_fit[-1] - popt[1]

#         if plot:
#             plt.figure(figsize=(10, 4))
#             plt.plot(x, y, '--', label='原始', color='gray')
#             plt.axhline(threshold, linestyle='--', color='purple', label=f'{int(fraction*100)}% 阈值')
#             plt.plot(x_fit, y_fit, label='拟合区段', color='blue')
#             plt.plot(x_fit, fitted, '--', label='高斯拟合', color='red')
#             plt.axvline(popt[1], linestyle=':', color='black', label='拟合峰位置')
#             plt.title(f"阈值高斯拟合 FWHM={fwhm:.2f}")
#             plt.legend()
#             plt.tight_layout()
#             plt.show()

#         return fwhm_left, fwhm_right, sigma

#     except Exception as e:
#         print(f"[拟合失败]: {e}")
#         return 0, 0, 0


# def asymmetric_gaussian_fwhm(profile, peak_x, ratio=0.5, max_fit_len=30):
#     x = np.arange(len(profile))
#     y = profile

#     if y[peak_x] < np.max(y):
#         peak_x = int(np.argmax(y))

#     threshold = compute_threshold(y, peak_x, ratio=ratio)

#     # 提取左侧和右侧 > 阈值的数据点
#     left_indices = np.where((x < peak_x) & (y >= threshold))[0][-max_fit_len:]
#     x_left = x[left_indices]
#     y_left = y[left_indices]

#     right_indices = np.where((x > peak_x) & (y >= threshold))[0][:max_fit_len]
#     x_right = x[right_indices]
#     y_right = y[right_indices]

#     print(f"[DEBUG] peak_x = {peak_x}, threshold = {threshold:.2f}")
#     print(f"[DEBUG] 左侧拟合点数 = {len(x_left)}，右侧拟合点数 = {len(x_right)}")

#     # 左拟合
#     fwhm_left = 0
#     fit_left = np.zeros_like(x_left)
#     if len(x_left) >= 3:
#         try:
#             baseline_left = np.min(y_left)
#             a_left = np.max(y_left) - baseline_left
#             x0_left = x_left[np.argmax(y_left)]
#             sigma_left = max(len(x_left) / 5, 1)
#             popt_left, _ = curve_fit(
#                 gaussian, x_left, y_left,
#                 p0=[a_left, x0_left, sigma_left, baseline_left],
#                 bounds=([0, x_left[0], 0.1, 0], [np.inf, x_left[-1], 50, np.max(y_left)]),
#                 maxfev=5000
#             )
#             if abs(popt_left[2]) >= 1e-3:
#                 fit_left = gaussian(x_left, *popt_left)
#                 fwhm_left = 2.355 * abs(popt_left[2])
#             else:
#                 print("⚠️ 左 σ 过小，忽略拟合")
#         except Exception as e:
#             print("❌ 左高斯拟合失败:", e)

#     # 右拟合
#     fwhm_right = 0
#     fit_right = np.zeros_like(x_right)
#     if len(x_right) >= 3:
#         try:
#             baseline_right = np.min(y_right)
#             a_right = np.max(y_right) - baseline_right
#             x0_right = x_right[np.argmax(y_right)]
#             sigma_right = max(len(x_right) / 5, 1)
#             popt_right, _ = curve_fit(
#                 gaussian, x_right, y_right,
#                 p0=[a_right, x0_right, sigma_right, baseline_right],
#                 bounds=([0, x_right[0], 0.1, 0], [np.inf, x_right[-1], 50, np.max(y_right)]),
#                 maxfev=5000
#             )
#             if abs(popt_right[2]) >= 1e-3:
#                 fit_right = gaussian(x_right, *popt_right)
#                 fwhm_right = 2.355 * abs(popt_right[2])
#             else:
#                 print("⚠️ 右 σ 过小，忽略拟合")
#         except Exception as e:
#             print("❌ 右高斯拟合失败:", e)

#     fwhm_total = (fwhm_left + fwhm_right) / 2 if (fwhm_left > 0 and fwhm_right > 0) else max(fwhm_left, fwhm_right)

#     # ✅ 可视化
#     plt.figure(figsize=(10, 5))
#     plt.plot(x, y, label='origin Profile', color='black')
#     plt.axhline(threshold, linestyle='--', color='purple', alpha=0.5, label=f'{int(ratio*100)}% 阈值')
#     if len(x_left) > 0:
#         plt.plot(x_left, y_left, color='blue', linewidth=2, label=f'Left > {int(ratio*100)}% 数据')
#         if fwhm_left > 0:
#             plt.plot(x_left, fit_left, '--', color='blue', label='Left Gaussian Fitting')
#             y_half_l = popt_left[3] + popt_left[0] / 2
#             x_half_l = x_left[np.argmin(np.abs(fit_left - y_half_l))]
#             plt.axvline(x_half_l, linestyle=':', color='blue', label='左半高位置')
#             plt.axhline(y_half_l, linestyle=':', color='blue', alpha=0.4)

#     if len(x_right) > 0:
#         plt.plot(x_right, y_right, color='red', linewidth=2, label=f'Right > {int(ratio*100)}% 数据')
#         if fwhm_right > 0:
#             plt.plot(x_right, fit_right, '--', color='red', label='Right Gaussian Fitting')
#             y_half_r = popt_right[3] + popt_right[0] / 2
#             x_half_r = x_right[np.argmin(np.abs(fit_right - y_half_r))]
#             plt.axvline(x_half_r, linestyle=':', color='red', label='右半高位置')
#             plt.axhline(y_half_r, linestyle=':', color='red', alpha=0.4)

#     plt.axvline(peak_x, linestyle=':', color='gray', label='峰中心')
#     plt.title(f'左右半高斯拟合（FWHM: {fwhm_total:.2f}）')
#     plt.xlabel('像素位置')
#     plt.ylabel('灰度值')
#     plt.legend()
#     plt.tight_layout()
#     plt.show()

#     print(f"[非对称高斯拟合] FWHM 左={fwhm_left:.2f}, 右={fwhm_right:.2f}, 合并={fwhm_total:.2f}")
#     return fwhm_left, fwhm_right


# def asymmetric_gaussian_fwhm(profile, ratio=0.6, max_fit_len=80, spline_factor=10):
#     # Step 1: 样条插值
#     if ratio < 0 or ratio > 1:
#         print(f"[警告] ratio 参数异常（{ratio}），已重置为 0.7")
#         ratio = 0.6

#     x = np.arange(len(profile))
#     cs = CubicSpline(x, profile)

#     x_dense = np.linspace(0, len(profile) - 1, len(profile) * spline_factor)
#     y_dense = cs(x_dense)

#     print(f"[DEBUG] profile 最大值: {np.max(profile)}")
#     print(f"[DEBUG] y_dense 最大值: {np.max(y_dense)}")


#     # Step 2: 亚像素峰值位置 & 阈值计算
#     peak_idx = np.argmax(y_dense)
#     peak_x = x_dense[peak_idx]
#     peak_val = y_dense[peak_idx]
#     baseline = np.min(y_dense)
#     threshold = baseline + (peak_val - baseline) * ratio
#     print(f"[DEBUG] peak_idx = {peak_idx}")
#     print(f"[DEBUG] peak_x = {peak_x}")
#     print(f"[DEBUG] peak_val = {peak_val}")
#     print(f"[DEBUG] baseline = {baseline}")
#     print(f"[DEBUG] threshold = {threshold}")
#     print(f"[DEBUG] ratio 参数 = {ratio}")



#     # Step 3: 左右侧提取大于 threshold 的插值数据
#     left_mask = (x_dense < peak_x) & (y_dense >= threshold)
#     right_mask = (x_dense > peak_x) & (y_dense >= threshold)

#     x_left = x_dense[left_mask][-max_fit_len:]
#     y_left = y_dense[left_mask][-max_fit_len:]
#     x_right = x_dense[right_mask][:max_fit_len]
#     y_right = y_dense[right_mask][:max_fit_len]

#     # 防止拟合失败：去除 NaN（若有）
#     valid_l = ~np.isnan(y_left)
#     valid_r = ~np.isnan(y_right)
#     x_left, y_left = x_left[valid_l], y_left[valid_l]
#     x_right, y_right = x_right[valid_r], y_right[valid_r]

#     print(f"[DEBUG] 插值峰位置: {peak_x:.2f}, 阈值: {threshold:.2f}")
#     print(f"[DEBUG] 左拟合点数: {len(x_left)}, 右拟合点数: {len(x_right)}")

#     # Step 4: 拟合
#     fwhm_left = fwhm_right = 0
#     fit_left = np.zeros_like(x_left)
#     fit_right = np.zeros_like(x_right)

#     if len(x_left) >= 3:
#         try:
#             baseline_l = np.min(y_left)
#             a_l = np.max(y_left) - baseline_l
#             x0_l = x_left[np.argmax(y_left)]
#             sigma_l = max(len(x_left) / 5, 1)
#             popt_l, _ = curve_fit(
#                 gaussian, x_left, y_left,
#                 p0=[a_l, x0_l, sigma_l, baseline_l],
#                 bounds=([0, x_left[0], 0.1, 0], [np.inf, x_left[-1], 50, np.max(y_left)]),
#                 maxfev=5000
#             )
#             fit_left = gaussian(x_left, *popt_l)
#             fwhm_left = 2.355 * abs(popt_l[2])
#         except Exception as e:
#             print("❌ 左高斯拟合失败:", e)

#     if len(x_right) >= 3:
#         try:
#             baseline_r = np.min(y_right)
#             a_r = np.max(y_right) - baseline_r
#             x0_r = x_right[np.argmax(y_right)]
#             sigma_r = max(len(x_right) / 5, 1)
#             popt_r, _ = curve_fit(
#                 gaussian, x_right, y_right,
#                 p0=[a_r, x0_r, sigma_r, baseline_r],
#                 bounds=([0, x_right[0], 0.1, 0], [np.inf, x_right[-1], 50, np.max(y_right)]),
#                 maxfev=5000
#             )
#             fit_right = gaussian(x_right, *popt_r)
#             fwhm_right = 2.355 * abs(popt_r[2])
#         except Exception as e:
#             print("❌ 右高斯拟合失败:", e)

#     fwhm_total = (fwhm_left + fwhm_right) / 2 if (fwhm_left > 0 and fwhm_right > 0) else max(fwhm_left, fwhm_right)


#     # Step 5: 可视化
#     plt.figure(figsize=(10, 5))
#     plt.plot(x_dense, y_dense, color='black', label='origin Profile')
#     plt.axvline(peak_x, linestyle=':', color='gray', label='峰中心')
#     plt.axhline(threshold, linestyle='--', color='purple', alpha=0.5, label=f'{int(ratio*100)}% 阈值')

#     if len(x_left) > 0:
#         plt.plot(x_left, y_left, color='blue', label=f'Left > {int(ratio*100)}% 数据')
#         if fwhm_left > 0:
#             plt.plot(x_left, fit_left, '--', color='blue', label='Left Gaussian Fit')

#     if len(x_right) > 0:
#         plt.plot(x_right, y_right, color='red', label=f'Right > {int(ratio*100)}% 数据')
#         if fwhm_right > 0:
#             plt.plot(x_right, fit_right, '--', color='red', label='Right Gaussian Fit')

#     if fwhm_left > 0:
#         y_half_l = popt_l[3] + popt_l[0] / 2  # 半高线高度 = baseline + a/2
#         x_half_l = x_left[np.argmin(np.abs(fit_left - y_half_l))]  # 找到拟合曲线最接近半高的位置
#         plt.axhline(y_half_l, linestyle='--', color='blue', alpha=0.3)
#         plt.axvline(x_half_l, linestyle=':', color='blue', label='左 FWHM 位置')
#         plt.text(x_half_l, y_half_l + 2, f"{x_half_l:.1f}", color='blue')

#     if fwhm_right > 0:
#         y_half_r = popt_r[3] + popt_r[0] / 2
#         x_half_r = x_right[np.argmin(np.abs(fit_right - y_half_r))]
#         plt.axhline(y_half_r, linestyle='--', color='red', alpha=0.3)
#         plt.axvline(x_half_r, linestyle=':', color='red', label='右 FWHM 位置')
#         plt.text(x_half_r, y_half_r + 2, f"{x_half_r:.1f}", color='red')



#     plt.title(f'左右半高斯拟合（FWHM: {fwhm_total:.2f}）')
#     plt.xlabel("像素位置")
#     plt.ylabel("灰度值")
#     plt.legend()
#     plt.tight_layout()
#     plt.show()

#     print(f"[非对称高斯拟合] FWHM 左={fwhm_left:.2f}, 右={fwhm_right:.2f}, 合并={fwhm_total:.2f}")
#     return fwhm_left, fwhm_right#, fwhm_total, peak_x
import numpy as np
import matplotlib.pyplot as plt
from scipy.optimize import curve_fit
from scipy.interpolate import CubicSpline
import config

# 高斯函数
def gaussian(x, a, x0, sigma, baseline):
    return a * np.exp(-(x - x0)**2 / (2 * sigma**2)) + baseline

# 计算阈值
def compute_threshold(y, peak_idx, ratio):
    baseline = np.min(y)
    peak_val = y[peak_idx]
    return baseline + (peak_val - baseline) * ratio

# 主函数：异步高斯拟合
def asymmetric_gaussian_fwhm(profile,  max_fit_len=80, spline_factor=10):
    # Step 1: 样条插值
    ratio=config.ratio
    if ratio < 0 or ratio > 1:
        print(f"[警告] ratio 参数异常（{ratio}），已重置为 （{config.ratio}）")
        ratio = 0.5

    x = np.arange(len(profile))
    cs = CubicSpline(x, profile)

    # 高分辨率插值
    x_dense = np.linspace(0, len(profile) - 1, len(profile) * spline_factor)
    y_dense = cs(x_dense)

    print(f"[DEBUG] profile 最大值: {np.max(profile)}")
    print(f"[DEBUG] y_dense 最大值: {np.max(y_dense)}")

    # Step 2: 亚像素峰值位置 & 阈值计算
    #peak_idx = np.argmax(y_dense)
    peak_idx = np.argmax(y_dense)
    peak_x = x_dense[peak_idx]
    peak_val = y_dense[peak_idx]
    baseline = np.min(y_dense)
    threshold = baseline + (peak_val - baseline) * ratio  

    lb_ub=(np.max(y_dense))*0.55
    y_dense_max=np.max(y_dense)
    baseline_lr = np.min(profile)


    print(f"[DEBUG] peak_idx = {peak_idx}")
    print(f"[DEBUG] peak_x = {peak_x}")
    print(f"[DEBUG] peak_val = {peak_val}")
    print(f"[DEBUG] baseline = {baseline}")
    print(f"[DEBUG] threshold = {threshold}")
    print(f"[DEBUG] ratio 参数 = {ratio}")

    # Step 3: 找到阈值位置 threshold_xL 和 threshold_xR
    threshold_xL = x_dense[np.where(y_dense >= threshold)[0][0]]
    threshold_xR = x_dense[np.where(y_dense >= threshold)[0][-1]]


    # Step 4: 提取左右区间数据
    left_mask = (x_dense >= threshold_xL) & (x_dense <= peak_x)
    right_mask = (x_dense >= peak_x) & (x_dense <= threshold_xR)

    x_left = x_dense[left_mask]
    y_left = y_dense[left_mask]
    x_right = x_dense[right_mask]
    y_right = y_dense[right_mask]

    # 防止拟合失败：去除 NaN（若有）
    valid_l = ~np.isnan(y_left)
    valid_r = ~np.isnan(y_right)
    x_left, y_left = x_left[valid_l], y_left[valid_l]
    x_right, y_right = x_right[valid_r], y_right[valid_r]

    print(f"[DEBUG] 左区间数据点: {len(x_left)}, 右区间数据点: {len(x_right)}")

    # Step 5: 左右半高斯拟合
    fwhm_left = fwhm_right = 0
    fit_left = np.zeros_like(x_left)
    fit_right = np.zeros_like(x_right)

    # 左侧拟合
    if len(x_left) >= 3:
        try:
            baseline_l = np.min(y_left)
            print(f"[DEBUG] baseline_l = {baseline_l}")

            a_l = np.max(y_left) - baseline_l
            x0_l = peak_x  # 使用 peak_x 为拟合中心
            sigma_l = np.std(x_left)  # 用标准差估计初始值
            popt_l, _ = curve_fit(
                gaussian, x_left, y_left,
                p0=[a_l, x0_l, sigma_l, baseline_l],
                #bounds=([0, x_left[0], 0.1, 0], [np.inf, x_left[-1], 50, np.max(y_left)]),
                #bounds = ([0, x_left[0], 0.1, baseline_l - 20], [np.inf, x_left[-1], 50, baseline_l + 20]),
                bounds = ([0, x_left[0], 0.1, baseline_lr+10], [np.inf, x_left[-1]+5, 50, lb_ub ]),

                maxfev=5000
            )
            
            print(f"[左侧拟合] a = {popt_l[0]:.2f}, x0 = {popt_l[1]:.2f}, σ = {popt_l[2]:.2f}, offset = {popt_l[3]:.2f}")
            offset_l=popt_l[3]


            fit_left = gaussian(x_left, *popt_l)
            fwhm_left = 2.355 * abs(popt_l[2])  # FWHM = 2.355 * σ
        except Exception as e:
            print("❌ 左高斯拟合失败:", e)

    # 右侧拟合
    if len(x_right) >= 3:
        try:
            baseline_r = np.min(y_right)
            print(f"[DEBUG] baseline_r = {baseline_r}")
            a_r = np.max(y_right) - baseline_r
            x0_r = peak_x  # 使用 peak_x 为拟合中心
            sigma_r = np.std(x_right)  # 用标准差估计初始值
            popt_r, _ = curve_fit(
                gaussian, x_right, y_right,
                p0=[a_r, x0_r, sigma_r, baseline_r],
                #bounds=([0, x_right[0], 0.1, 0], [np.inf, x_right[-1], 50, np.max(y_right)]),
                #bounds = ([0, x_right[0], 0.1, baseline_r - 20],[np.inf, x_right[-1], 50, baseline_r + 20]),
                bounds = ([0, x_right[0]-5, 0.1, baseline_lr+10],[np.inf, x_right[-1], 50, lb_ub]),

                maxfev=5000
            )
            #print(f"右侧拟合参数 popt_r: a={popt_r[0]:.2f}, offset={popt_r[3]:.2f}")
            print(f"[左侧拟合] a = {popt_r[0]:.2f}, x0 = {popt_r[1]:.2f}, σ = {popt_r[2]:.2f}, offset = {popt_r[3]:.2f}")
            offset_r=popt_r[3]

            fit_right = gaussian(x_right, *popt_r)
            fwhm_right = 2.355 * abs(popt_r[2])  # FWHM = 2.355 * σ
        except Exception as e:
            print("❌ 右高斯拟合失败:", e)

    if (offset_l/y_dense_max)-(offset_r/y_dense_max)>0.12 or (offset_r/y_dense_max)-(offset_l/y_dense_max)>0.12 :
        print("左右offset差值过大")
        if offset_l>offset_r:
            #youbian
            try:
                a_r = np.max(y_right) - baseline_r
                x0_r = peak_x  # 使用 peak_x 为拟合中心
                sigma_r = np.std(x_right)  # 用标准差估计初始值
                popt_r, _ = curve_fit(
                    gaussian, x_right, y_right,
                    p0=[a_r, x0_r, sigma_r, baseline_r],
                    #bounds=([0, x_right[0], 0.1, 0], [np.inf, x_right[-1], 50, np.max(y_right)]),
                    #bounds = ([0, x_right[0], 0.1, baseline_r - 20],[np.inf, x_right[-1], 50, baseline_r + 20]),
                    bounds = ([0, x_right[0]-5, 0.1, offset_l-5],[np.inf, x_right[-1], 50, offset_l+10]),

                    maxfev=5000
                )
                #print(f"右侧拟合参数 popt_r: a={popt_r[0]:.2f}, offset={popt_r[3]:.2f}")
                print(f"[左侧拟合] a = {popt_r[0]:.2f}, x0 = {popt_r[1]:.2f}, σ = {popt_r[2]:.2f}, offset = {popt_r[3]:.2f}")
                offset_r=popt_r[3]

                fit_right = gaussian(x_right, *popt_r)
                fwhm_right = 2.355 * abs(popt_r[2])  # FWHM = 2.355 * σ
            except Exception as e:
                print("❌ 右高斯拟合失败:", e)
        
        if offset_r>offset_l:
            #左边
            try:

                a_l = np.max(y_left) - baseline_l
                x0_l = peak_x  # 使用 peak_x 为拟合中心
                sigma_l = np.std(x_left)  # 用标准差估计初始值
                popt_l, _ = curve_fit(
                    gaussian, x_left, y_left,
                    p0=[a_l, x0_l, sigma_l, baseline_l],
                    #bounds=([0, x_left[0], 0.1, 0], [np.inf, x_left[-1], 50, np.max(y_left)]),
                    #bounds = ([0, x_left[0], 0.1, baseline_l - 20], [np.inf, x_left[-1], 50, baseline_l + 20]),
                    bounds = ([0, x_left[0], 0.1, offset_r]-5, [np.inf, x_left[-1]+5, 50, offset_r+10 ]),

                    maxfev=5000
                )
                
                print(f"[左侧拟合] a = {popt_l[0]:.2f}, x0 = {popt_l[1]:.2f}, σ = {popt_l[2]:.2f}, offset = {popt_l[3]:.2f}")
                offset_l=popt_l[3]

                fit_left = gaussian(x_left, *popt_l)
                fwhm_left = 2.355 * abs(popt_l[2])  # FWHM = 2.355 * σ
            except Exception as e:
                print("❌ 左高斯拟合失败:", e)




    fwhm_total = (fwhm_left + fwhm_right) / 2 if fwhm_left and fwhm_right else max(fwhm_left, fwhm_right)
    
    # Step 6: 可视化
    plt.figure(figsize=(10, 5))
    plt.plot(x_dense, y_dense, color='black', label='origin Profile')
    plt.axvline(peak_x, linestyle=':', color='gray', label='峰中心')
    plt.axhline(threshold, linestyle='--', color='purple', alpha=0.5, label=f'{int(ratio*100)}% 阈值')

    # 左侧数据和拟合
    if len(x_left) > 0:
        plt.plot(x_left, y_left, color='blue', label=f'Left > {int(ratio*100)}% 数据')
        if fwhm_left > 0:
            plt.plot(x_left, fit_left, '--', color='blue', label='Left Gaussian Fit')
            # 半高宽位置可视化
            y_half_l = popt_l[3] + popt_l[0] / 2
            x_half_l = x_left[np.argmin(np.abs(fit_left - y_half_l))]
            plt.axhline(y_half_l, linestyle='--', color='blue', alpha=0.3)
            plt.axvline(x_half_l, linestyle=':', color='blue', label='左 FWHM 位置')
            plt.text(x_half_l, y_half_l + 2, f"{x_half_l:.1f}", color='blue')

    # 右侧数据和拟合
    if len(x_right) > 0:
        plt.plot(x_right, y_right, color='red', label=f'Right > {int(ratio*100)}% 数据')
        if fwhm_right > 0:
            plt.plot(x_right, fit_right, '--', color='red', label='Right Gaussian Fit')
            # 半高宽位置可视化
            y_half_r = popt_r[3] + popt_r[0] / 2
            x_half_r = x_right[np.argmin(np.abs(fit_right - y_half_r))]
            plt.axhline(y_half_r, linestyle='--', color='red', alpha=0.3)
            plt.axvline(x_half_r, linestyle=':', color='red', label='右 FWHM 位置')
            plt.text(x_half_r, y_half_r + 2, f"{x_half_r:.1f}", color='red')

    # 左侧完整拟合
    if fwhm_left > 0:
        full_fit_left = gaussian(x_dense, *popt_l)
        plt.plot(x_dense, full_fit_left, '--', color='blue', alpha=0.6, label='Left Gaussian Fit (full)')

    # 右侧完整拟合
    if fwhm_right > 0:
        full_fit_right = gaussian(x_dense, *popt_r)
        plt.plot(x_dense, full_fit_right, '--', color='red', alpha=0.6, label='Right Gaussian Fit (full)')

    plt.title(f'左右半高斯拟合（FWHM: {fwhm_total:.2f}）')
    plt.xlabel("像素位置")
    plt.ylabel("灰度值")
    plt.legend()
    plt.tight_layout()
    plt.show()

    print(f"[非对称高斯拟合] FWHM 左={fwhm_left:.2f}, 右={fwhm_right:.2f}, 合并={fwhm_total:.2f}")
    return fwhm_left, fwhm_right
