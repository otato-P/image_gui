import numpy as np
import json

class ROIResult:
    def __init__(self, coords, mean_values, slope, intercept,
                 smooth_profile=None, peaks=None, axis=None):
        self.coords = coords  # ROI 区域坐标 (x1, y1, x2, y2)
        self.mean_values = np.array(mean_values)
        self.slope = float(slope)
        self.intercept = float(intercept)
        self.smooth_profile = np.array(smooth_profile) if smooth_profile is not None else None
        self.peaks = np.array(peaks) if peaks is not None else None
        self.axis = axis  # "row" or "col"

    def to_dict(self):
        return {
            "coords": self.coords,
            "mean_values": self.mean_values.tolist(),
            "slope": self.slope,
            "intercept": self.intercept,
            "smooth_profile": self.smooth_profile.tolist() if self.smooth_profile is not None else None,
            "peaks": self.peaks.tolist() if self.peaks is not None else None,
            "axis": self.axis
        }

    @classmethod
    def from_dict(cls, d):
        return cls(
            coords=d["coords"],
            mean_values=d["mean_values"],
            slope=d["slope"],
            intercept=d["intercept"],
            smooth_profile=d.get("smooth_profile"),
            peaks=d.get("peaks"),
            axis=d.get("axis")
        )
