
import json
import matplotlib.pyplot as plt
import numpy as np
from .roi_result import ROIResult

class ROIDataManager:
    def __init__(self):
        self.results = {}  # key = image_name, value = list of ROIResult

    def add_result(self, image_name, roi_result: ROIResult):
        if image_name not in self.results:
            self.results[image_name] = []
        self.results[image_name].append(roi_result)

    def save_to_json(self, path):
        data = {
            image_name: [roi.to_dict() for roi in roi_list]
            for image_name, roi_list in self.results.items()
        }
        with open(path, "w") as f:
            json.dump(data, f, indent=2)

    def load_from_json(self, path):
        with open(path, "r") as f:
            data = json.load(f)
        self.results = {
            image_name: [ROIResult.from_dict(d) for d in roi_list]
            for image_name, roi_list in data.items()
        }

    def plot_all_fits(self):
        plt.figure(figsize=(10, 6))
        for image_name, roi_list in self.results.items():
            for i, result in enumerate(roi_list):
                x = np.arange(len(result.mean_values))
                y_fit = result.slope * x + result.intercept
                label = f"{image_name} ROI {i+1}"
                plt.plot(x, y_fit, label=label)
        plt.xlabel("X (Column Index)")
        plt.ylabel("Mean Intensity")
        plt.title("Linear Fit of ROI Intensity")
        plt.legend()
        plt.grid(True)
        plt.tight_layout()
        plt.show()

    def plot_all_with_peaks(self):
        plt.figure(figsize=(10, 6))
        for image_name, roi_list in self.results.items():
            for i, result in enumerate(roi_list):
                x = np.arange(len(result.mean_values))
                label = f"{image_name} ROI {i+1}"
                plt.plot(x, result.mean_values, label=label)
                if result.peaks is not None and result.smooth_profile is not None:
                    plt.plot(result.peaks, result.smooth_profile[result.peaks], 'ro')
        plt.xlabel("X (Column Index)")
        plt.ylabel("Mean Intensity")
        plt.title("ROI Mean Intensity with Peak Positions")
        plt.legend()
        plt.grid(True)
        plt.tight_layout()
        plt.show()

