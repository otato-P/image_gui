import numpy as np
from scipy.interpolate import interp1d
import matplotlib.pyplot as plt
from scipy.signal import savgol_filter
from scipy.interpolate import CubicSpline

# def compute_half_max(profile, peak_x, window=8):
#     left_bg = profile[max(0, peak_x - window*2):max(0, peak_x - window)]
#     right_bg = profile[min(len(profile)-1, peak_x + window):min(len(profile)-1, peak_x + window*2)]

#     local_baseline = np.median(np.concatenate([left_bg, right_bg]))  # 更抗噪
#     peak_val = profile[peak_x]

#     return local_baseline + (peak_val - local_baseline) / 2

# def compute_half_max_subtract_baseline(profile, peak_x, fraction=0.7):
#     """
#     先用峰高的某比例估计背景，然后从 profile 中扣除，再计算半高值
#     """
#     peak_val = profile[peak_x]
#     baseline = peak_val * fraction  # 估计背底
    
#     adjusted = profile - baseline
#     adjusted = np.clip(adjusted, a_min=0, a_max=None)  # 避免负值影响

#     peak_adjusted = adjusted[peak_x]
#     half_max = peak_adjusted / 2

#     return half_max, baseline, adjusted

# def compute_half_max_subtract_baseline(y_spline, peak_x, fraction=0.7):
#     """
#     在平滑曲线 y_spline 上，先按比例估算背景值，再做扣除，最后计算半高
#     """
#     peak_val = y_spline[peak_x]
#     baseline = peak_val * fraction

#     y_adjusted = y_spline - baseline
#     y_adjusted = np.clip(y_adjusted, a_min=0, a_max=None)

#     half_max = y_adjusted[peak_x] / 2
#     return half_max, baseline, y_adjusted


# def estimate_fwhm_geometrically(profile, peak_x,fraction=0.5):
    
#     x = np.arange(len(profile))
#     #y = profile
#     #y = savgol_filter(profile, window_length=9, polyorder=3)
#     cs = CubicSpline(x, profile)
#     y = cs(x)

#     half_max = compute_percent_by_peak_fraction(y, peak_x,fraction=fraction)

#     # ➤ 左侧
#     left_half = y[:peak_x + 1][::-1]
#     below_l = np.where(left_half < half_max)[0]
#     if below_l.size < 1 or (peak_x - below_l[0] - 1 < 0):
#         fwhm_left = 0
#     else:
#         idx1 = below_l[0]
#         i1 = peak_x - idx1 + 1
#         x_vals_l = x[i1 - 1: i1 + 1]
#         y_vals_l = y[i1 - 1: i1 + 1]
#         try:
#             f_interp = interp1d(y_vals_l, x_vals_l)
#             x_cross = f_interp(half_max)
#             fwhm_left = peak_x - x_cross
#         except:
#             fwhm_left = 0

#     # ➤ 右侧
#     right_half = y[peak_x:]
#     below_r = np.where(right_half < half_max)[0]
#     if below_r.size < 1 or (peak_x + below_r[0] + 1 >= len(y)):
#         fwhm_right = 0
#     else:
#         idx2 = below_r[0]
#         x_vals_r = x[peak_x + idx2 - 1: peak_x + idx2 + 1]
#         y_vals_r = y[peak_x + idx2 - 1: peak_x + idx2 + 1]
#         try:
#             f_interp = interp1d(y_vals_r, x_vals_r)
#             x_cross = f_interp(half_max)
#             fwhm_right = x_cross - peak_x
#         except:
#             fwhm_right = 0

#     return fwhm_left, fwhm_right

# def plot_direct_fwhm(profile, peak_x, fwhm_left, fwhm_right,fraction=0.5,save_path=None,show=True):
#     x = np.arange(len(profile))
#     #y = profile
#     #y = savgol_filter(profile, window_length=9, polyorder=3)
#     cs=CubicSpline(x,profile)
#     y=cs(x)
#     half_max = compute_percent_by_peak_fraction(profile, peak_x,fraction=fraction)

#     x_left = peak_x - fwhm_left
#     x_right = peak_x + fwhm_right

#     plt.figure(figsize=(10, 4))
#     plt.plot(x, profile, label="原始 Profile", color='gray', linestyle='--', linewidth=1)
#     plt.plot(x, y, label="三次样条平滑", color='black')
#     plt.axvline(peak_x, linestyle=':', color='gray', label='峰位置')

#     plt.axhline(half_max, linestyle='--', color='purple', label=f'{int(fraction * 100)}% 高度线')

#     plt.axvline(x_left, linestyle=':', color='blue', label='左交点')
#     plt.text(x_left, half_max + 2, f"{x_left:.1f}", color='blue')

#     plt.axvline(x_right, linestyle=':', color='red', label='右交点')
#     plt.text(x_right, half_max + 2, f"{x_right:.1f}", color='red')

#     plt.title(f"直接拟合 FWHM（总宽度: {fwhm_left + fwhm_right:.2f}）")
#     plt.xlabel("像素位置")
#     plt.ylabel("灰度值")
#     plt.legend()
#     plt.tight_layout()
#     plt.show()
#     if save_path:
#         plt.savefig(save_path)
#         print(f"[图像已保存至] {save_path}")

#     if show:
#         plt.show()
#     else:
#         plt.close()
import numpy as np
import matplotlib.pyplot as plt
from scipy.optimize import curve_fit
from scipy.interpolate import CubicSpline
import config


# 计算阈值
def compute_threshold(y, peak_idx, ratio):
    baseline = np.min(y)
    peak_val = y[peak_idx]
    return baseline + (peak_val - baseline) * ratio

# 主函数：对拟合函数直接取半高宽

def estimate_fwhm_geometrically(profile, peak_x):
    
    #def direct_fwhm(profile,  max_fit_len=80, spline_factor=10):
    # Step 1: 样条插值
    ratio=config.ratio
    spline_factor=10
    if ratio < 0 or ratio > 1:
        print(f"[警告] ratio 参数异常（{ratio}），已重置为 （{config.ratio}）")
        ratio = 0.6

    x = np.arange(len(profile))
    cs = CubicSpline(x, profile)

    # 高分辨率插值
    x_dense = np.linspace(0, len(profile) - 1, len(profile) * spline_factor)
    y_dense = cs(x_dense)

    print(f"[DEBUG] profile 最大值: {np.max(profile)}")
    print(f"[DEBUG] y_dense 最大值: {np.max(y_dense)}")

    # Step 2: 亚像素峰值位置 & 阈值计算
    peak_idx = np.argmax(y_dense)
    peak_x = x_dense[peak_idx]
    peak_val = y_dense[peak_idx]
    baseline = np.min(y_dense)
    threshold = baseline + (peak_val - baseline) * ratio

    print(f"[DEBUG] peak_idx = {peak_idx}")
    print(f"[DEBUG] peak_x = {peak_x}")
    print(f"[DEBUG] peak_val = {peak_val}")
    print(f"[DEBUG] baseline = {baseline}")
    print(f"[DEBUG] threshold = {threshold}")
    print(f"[DEBUG] ratio 参数 = {ratio}")

    # Step 3: 找到阈值位置 threshold_xL 和 threshold_xR
    threshold_xL = x_dense[np.where(y_dense >= threshold)[0][0]]
    threshold_xR = x_dense[np.where(y_dense >= threshold)[0][-1]]

    fwhm_left=peak_x-threshold_xL
    fwhm_right=threshold_xR-peak_x 




    fwhm_total = (fwhm_left + fwhm_right) / 2 if fwhm_left and fwhm_right else max(fwhm_left, fwhm_right)

    # Step 6: 可视化
    plt.figure(figsize=(10, 5))
    plt.plot(x_dense, y_dense, color='black', label='origin Profile')
    plt.axvline(peak_x, linestyle=':', color='gray', label='峰中心')
    plt.axhline(threshold, linestyle='--', color='purple', alpha=0.5, label=f'{int(ratio*100)}% 阈值')

    plt.title(f'左右半高斯拟合（FWHM: {fwhm_total:.2f}）')
    plt.xlabel("像素位置")
    plt.ylabel("灰度值")
    plt.legend()
    plt.tight_layout()
    plt.show()

    print(f"[非对称高斯拟合] FWHM 左={fwhm_left:.2f}, 右={fwhm_right:.2f}, 合并={fwhm_total:.2f}")
    return fwhm_left, fwhm_right


# def estimate_fwhm_geometrically(profile, peak_x, fraction=0.7):
#     """
#     基于扣除背景后的 profile 来估计左右 FWHM
#     """
#     x = np.arange(len(profile))
#     cs = CubicSpline(x, profile)
#     y = cs(x)

#     half_max, baseline, y_adjusted = compute_half_max_subtract_baseline(y, peak_x, fraction=fraction)

#     # 左侧
#     left_half = y_adjusted[:peak_x + 1][::-1]
#     below_l = np.where(left_half < half_max)[0]
#     if below_l.size < 1 or (peak_x - below_l[0] - 1 < 0):
#         fwhm_left = 0
#     else:
#         idx1 = below_l[0]
#         i1 = peak_x - idx1 + 1
#         x_vals_l = x[i1 - 1: i1 + 1]
#         y_vals_l = y_adjusted[i1 - 1: i1 + 1]
#         try:
#             f_interp = interp1d(y_vals_l, x_vals_l)
#             x_cross = f_interp(half_max)
#             fwhm_left = peak_x - x_cross
#         except:
#             fwhm_left = 0

#     # 右侧
#     right_half = y_adjusted[peak_x:]
#     below_r = np.where(right_half < half_max)[0]
#     if below_r.size < 1 or (peak_x + below_r[0] + 1 >= len(y_adjusted)):
#         fwhm_right = 0
#     else:
#         idx2 = below_r[0]
#         x_vals_r = x[peak_x + idx2 - 1: peak_x + idx2 + 1]
#         y_vals_r = y_adjusted[peak_x + idx2 - 1: peak_x + idx2 + 1]
#         try:
#             f_interp = interp1d(y_vals_r, x_vals_r)
#             x_cross = f_interp(half_max)
#             fwhm_right = x_cross - peak_x
#         except:
#             fwhm_right = 0

#     return fwhm_left, fwhm_right, baseline, y, y_adjusted, half_max

# def plot_direct_fwhm(profile, peak_x, fwhm_left, fwhm_right, baseline, y_spline, y_adjusted, half_max, fraction=0.7, save_path=None, show=True):
#     """
#     绘制 FWHM 可视化图，展示原始曲线、样条平滑、去背景曲线及半高线
#     """
#     x = np.arange(len(profile))
#     x_left = peak_x - fwhm_left
#     x_right = peak_x + fwhm_right

#     plt.figure(figsize=(10, 4))
#     plt.plot(x, profile, label="原始 Profile", linestyle='--', color='gray')
#     plt.plot(x, y_spline, label="三次样条平滑", color='black')
#     plt.plot(x, y_adjusted, label="扣除背景后的曲线", color='blue')

#     plt.axvline(peak_x, linestyle=':', color='gray', label='峰位置')
#     plt.axhline(half_max, linestyle='--', color='purple', label='半高线')
#     plt.axhline(baseline, linestyle='--', color='orange', label=f'背景（{int(fraction*100)}%峰高）')

#     plt.axvline(x_left, linestyle=':', color='blue', label='左交点')
#     plt.text(x_left, half_max + 2, f"{x_left:.1f}", color='blue')

#     plt.axvline(x_right, linestyle=':', color='red', label='右交点')
#     plt.text(x_right, half_max + 2, f"{x_right:.1f}", color='red')

#     plt.title(f"直接拟合 FWHM（总宽度: {fwhm_left + fwhm_right:.2f}）")
#     plt.xlabel("像素位置")
#     plt.ylabel("灰度值")
#     plt.legend()
#     plt.tight_layout()

#     if save_path:
#         plt.savefig(save_path)
#         print(f"[图像已保存至] {save_path}")

#     if show:
#         plt.show()
#     else:
#         plt.close()
