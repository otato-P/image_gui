import math
import config
from scipy.optimize import fsolve, minimize_scalar
import numpy as np
from scipy.optimize import fsolve, root_scalar
def calculate_screen_distance(y1, y2):
    # 计算平行线之间的距离 B_ture
    B = abs(y2 - y1)
    config.screen_length=B

def calculate_theta(D):
    I=config.screen_ture_length
    B=config.screen_length
    L=config.screen_sample_length

    tan_theta = (D*I)/(2*B*L)
    theta = math.atan(tan_theta)  # Calculate the angle in radians
    return math.degrees(theta) 

def calculate_a(C):
    L=config.screen_sample_length
    I=config.screen_ture_length
    B=config.screen_length
    k=73.733
    a = (2 * math.pi * L * B) / (C* I * k)
    return a

def solve_d0_given_sigma0(c1, c2, k, theta_deg, sigma0):
    theta = math.radians(theta_deg)

    def equation(d):
        R = c1 / c2
        arg1 = np.clip(np.cos(theta) + d / (2 * k), -1, 1)
        arg2 = np.clip(np.cos(theta) - d / (2 * k), -1, 1)
        numerator = theta - np.arccos(arg1)
        denominator = np.arccos(arg2) - theta
        if denominator <= 0 or numerator <= 0:
            return np.inf
        rhs = np.exp(k * d * sigma0**2) * (numerator / denominator)
        return rhs - R

    d0 = fsolve(equation, x0=0.01)[0]
    return d0


def solve_sigma(c1, c2, k,  theta_deg, sigma0,sigma_range=(1e-3, 5.0)):
    theta = math.radians(theta_deg)
    d0 = solve_d0_given_sigma0(config.c1_sample, config.c2_sample, k, theta_deg, sigma0)
    alpha = d0 / sigma0
    def f_sigma(sigma):
        try:
            num = theta - np.arccos(np.clip(np.cos(theta) + (alpha * sigma) / (2 * k), -1, 1))
            den = np.arccos(np.clip(np.cos(theta) - (alpha * sigma) / (2 * k), -1, 1)) - theta
            if den <= 0 or num <= 0:
                return np.inf
            lhs = np.log(c1 / c2)
            rhs = k * alpha * sigma**3 + np.log(num / den)
            return lhs - rhs
        except Exception:
            return np.inf
        
    print(f"[DEBUG] solve_sigma 输入 c1={c1}, c2={c2}, ratio={c1/c2:.4f}, sigma0={sigma0}")

    a, b = sigma_range
    fa = f_sigma(a)
    fb = f_sigma(b)
    if fa * fb > 0:
        #raise ValueError(f"[brentq] 区间两端函数同号，f({a})={fa:.4e}, f({b})={fb:.4e}，不能使用 brentq")
        print(f"[FAIL] f({a:.3f})={fa:.4e}, f({b:.3f})={fb:.4e}，区间无根")
        raise ValueError("区间无根")
    result = root_scalar(f_sigma, bracket=sigma_range, method='brentq', xtol=1e-10)

   # debug_plot_f_sigma(f_sigma, sigma_range)

    if result.converged:
        print(f"[OK] root_scalar 成功收敛: σ = {result.root:.6f}")
        return result.root
    else:
        raise RuntimeError("σ 求解失败，请检查参数或搜索区间。")
    
    

import matplotlib.pyplot as plt

def debug_plot_f_sigma(f_sigma, sigma_range):
    sigmas = np.linspace(0.5, 5.0, 300) 
    values = [f_sigma(s) for s in sigmas]
    plt.plot(sigmas, values, label="f(σ)")
    plt.axhline(0, color='red', linestyle='--')
    plt.xlabel("σ")
    plt.ylabel("f(σ)")
    plt.title("f_sigma(σ) 曲线")
    plt.grid(True)
    plt.legend()
    plt.show()
# # Step 1: 标定阶段
# c1 = 1.63
# c2 = 1.07
# theta_deg = 1.57814
# sigma0 = 1.77
# k = 73.733

# d0 = solve_d0_given_sigma0(c1, c2, k, theta_deg, sigma0)
# alpha = d0 / sigma0
# print(f"[Step 1] 解出 d₀ = {d0:.6f}，比例 α = {alpha:.6f}")

# Step 2: 反解 σ

#sigma = solve_sigma_from_alpha(c1, c2, k, theta_deg,sigma0)
# import numpy as np
# from scipy.optimize import fsolve
# import math



# def solve_d0(c1,c2,theta,k,sigma0):
#     R = c1 / c2  # 左边的值
    
#     term1 = np.exp(k * d * sigma0**2)
#     # 确保反余弦函数内部合法（在[-1, 1]之间）
#     arg1 = np.clip(np.cos(theta) + d / (2 * k), -1, 1)
#     arg2 = np.clip(np.cos(theta) - d / (2 * k), -1, 1)
#     numerator = theta - np.arccos(arg1)
#     denominator = np.arccos(arg2) - theta
#     right = term1 * (numerator / denominator)
#     return right - R

# # 初始猜测
# initial_guess = 0.01

# # 求解 d
# solution = fsolve(equation, initial_guess)
# print("解出的 d =", solution[0])

# def equation_sigma_with_d(sigma, c1, c2, theta_deg, k, sigma0, d0):
#     if sigma <= 0:
#         return float('inf')

#     theta_rad = math.radians(theta_deg)
#     cos_theta = math.cos(theta_rad)
#     d = d0 * (sigma / sigma0)

#     try:
#         #exp_part = math.exp(k * d * sigma**2)
#         exponent = k * d * sigma**2
#         if exponent > 100:  # 防止指数爆炸
#             return float('inf')

#         exp_part = math.exp(exponent)
        

#         inner_plus = cos_theta + d / (2 * k)
#         inner_minus = cos_theta - d / (2 * k)

#         if not -1 <= inner_plus <= 1 or not -1 <= inner_minus <= 1:
#             return float('inf')

#         acos_plus = math.acos(inner_plus)
#         acos_minus = math.acos(inner_minus)

#         numerator = theta_rad - acos_plus
#         denominator = acos_minus - theta_rad

#         if denominator == 0:
#             return float('inf')

#         rhs = exp_part * (numerator / denominator)
#         lhs = c1 / c2

#         return lhs - rhs

#     except Exception as e:
#         print("[equation_sigma_with_ratio Error]", e)
#         return float('inf')

# def equation_sigma_log(sigma, c1, c2, theta_deg, k, d0, sigma0):
#     if sigma <= 0:
#         return float('inf')

#     theta_rad = math.radians(theta_deg)
#     cos_theta = math.cos(theta_rad)
#     d = d0 * (sigma / sigma0)

#     try:
#         inner_plus = cos_theta + d / (2 * k)
#         inner_minus = cos_theta - d / (2 * k)

#         if not -1 <= inner_plus <= 1 or not -1 <= inner_minus <= 1:
#             return float('inf')

#         acos_plus = math.acos(inner_plus)
#         acos_minus = math.acos(inner_minus)

#         numerator = theta_rad - acos_plus
#         denominator = acos_minus - theta_rad

#         if denominator == 0 or numerator <= 0 or denominator <= 0:
#             return float('inf')

#         log_lhs = math.log(c1 / c2)
#         log_rhs = k * d * sigma**2 + math.log(numerator / denominator)

#         return log_lhs - log_rhs

#     except Exception as e:
#         print("[equation_sigma_log Error]", e)
#         return float('inf')


# # ✅ 主求解函数：根据浓度比 c1/c2 和 θ 等，求解 σ
# def solve_sigma(c1, c2, theta_deg, k,d0,sigma0):
#     print(f"[solve_sigma] 输入参数: c1={c1:.4f}, c2={c2:.4f}, θ={theta_deg:.2f}, k={k:.2f}, d0={d0:.4f}, σ₀={sigma0:.4f}")

#     def objective(sigma):
#         return abs(equation_sigma_log(sigma, c1, c2, theta_deg, k, d0, sigma0))

#     result = minimize_scalar(
#         objective,
#         bounds=(1e-4, 2.0),# 自然范围，无需强限
#         method='bounded'
#     )

#     import matplotlib.pyplot as plt
#     import numpy as np

#     s_vals = np.linspace(0.01, 2.0, 200)
#     errors = [objective(s) for s in s_vals]
#     plt.plot(s_vals, errors)
#     plt.xlabel("σ")
#     plt.ylabel("误差")
#     plt.title("目标函数 abs(lhs - rhs(σ))")
#     plt.grid(True)
#     plt.show()


#     if result.success and result.x > 0:
#         return result.x
#     else:
#         raise ValueError("[ERROR] 无法求解有效的 σ 值，请检查输入参数。")

# # ✅ 可选函数：根据 d 与 d0 的比值直接计算 σ（若不使用公式 1）
# def sigma_from_d_ratio(d, d0, sigma0):
#     return sigma0 * d / d0

# # # 定义方程：传入 d，返回等式左右两边之差
# # def equation_d(d, c1, c2, theta, k, sigma):
# #     lhs = c1 / c2
# #     exp_part = math.exp(math.cos(theta) * k * d * sigma**2)

# #     numerator = theta - (math.acos(theta) + d / (2 * k))
# #     inner_cos = math.cos(theta) - d / (2 * k)

# #     # 防止 cos 值超出 [-1, 1]
# #     if inner_cos < -1 or inner_cos > 1:
# #         return float('inf')  # 返回一个极大值，避免报错

# #     denominator = math.acos(inner_cos) - theta

# #     if denominator == 0:
# #         return float('inf')  # 避免除以0

# #     rhs = exp_part * (numerator / denominator)
# #     return lhs - rhs

# # from scipy.optimize import fsolve

# # # 定义目标函数，变量是 sigma
# # def equation_sigma(sigma, c1, c2, theta, k, d):
# #     lhs = c1 / c2
# #     theta_rad = math.radians(theta)
# #     exp_part = math.exp(math.cos(theta_rad) * k * d * sigma**2)

# #     numerator = theta_rad - (math.acos(theta_rad) + d / (2 * k))
# #     inner_cos = math.cos(theta_rad) - d / (2 * k)

# #     if inner_cos < -1 or inner_cos > 1:
# #         return float('inf')

# #     denominator = math.acos(inner_cos) - theta_rad

# #     if denominator == 0:
# #         return float('inf')

# #     rhs = exp_part * (numerator / denominator)
# #     return lhs - rhs

# # def solve_sigma(c1, c2, theta_deg, k, d, sigma_guess=0.5):
# #     """
# #     求解满足非线性公式的 σ 值，确保 σ > 0。
# #     """
# #     def objective(s):
# #         return abs(equation_sigma(s, c1, c2, theta_deg, k, d))

# #     result = minimize_scalar(
# #         objective,
# #         bounds=(1e-6, 10),
# #         method='bounded'
# #     )

# #     if result.success and result.x > 0:
# #         return result.x
# #     else:
# #         raise ValueError("[ERROR] 无法求解正的 σ 值，请检查输入参数是否合理。")



# #  # 示例参数（你需要用你自己的数据替换）
# c1 = 0.4210
# c2 = 0.2780
# theta = 1.36389 # 角度转弧度
# d =0.18527
# k=73.733
# sigma0=0.177
# # 初始猜测值（sigma不能为负）
# try:
#     sigma_solution = solve_sigma(c1, c2, theta, k, d,sigma0)
#     print(f"计算得到的 σ 值是: {sigma_solution:.6f}")
# except ValueError as e:
#     print(f"[ERROR] σ 求解失败: {e}")

