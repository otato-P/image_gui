import os
import cv2

def load_images_from_folder(folder_path):
    image_list = []
    for filename in os.listdir(folder_path):
        if filename.lower().endswith(('.png', '.jpg', '.jpeg', '.bmp')):
            full_path = os.path.join(folder_path, filename)
            image = cv2.imread(full_path)
            if image is not None:
                image_list.append((filename, image))
    return image_list
