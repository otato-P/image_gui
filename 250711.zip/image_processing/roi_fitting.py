import cv2
import numpy as np
import matplotlib.pyplot as plt
from scipy.signal import savgol_filter
from scipy.signal import savgol_filter, find_peaks

from scipy.interpolate import CubicSpline

def fit_roi_data(roi):
    print("Inside fit_roi_data")
    print("ROI shape:", roi.shape)

    if roi.size == 0:
        print("空的ROI区域")
        return
    
    # 灰度图
    gray = cv2.cvtColor(roi, cv2.COLOR_BGR2GRAY)
    h, w = gray.shape

    # 自动判断方向
    if w >= h * 1.5:
        axis = 'col'   # ROI 宽远大于高 → 纵向分析
        profile = np.mean(gray, axis=0)
        x_label = "像素列位置 (x)"
    elif h >= w * 1.2:
        axis = 'row'   # ROI 高远大于宽 → 横向分析
        #profile = np.mean(gray, axis=1)
        #x_label = "像素行位置 (y)"

        # 先对每列求平均
        col_means = np.mean(gray, axis=0)
        #找到最亮列
        peak_col = int(np.argmax(col_means))
        # 取该列 ±2 共5列，注意边界
        start_col = max(0, peak_col - 2)
        end_col = min(w, peak_col + 3)  # 右边是闭区间
        selected = gray[:, start_col:end_col]

        # step 4: 对这5列做行方向平均
        profile = np.mean(selected, axis=1)

        x_label = "像素行位置 (y)"

    else:
        # 宽高相近：默认按列处理，也可以提示用户
        axis = 'col'
        profile = np.mean(gray, axis=0)
        x_label = "像素列位置 (x)"
        print("宽高相近，默认使用列方向分析")

   
    #三次样条
    x = np.arange(len(profile))
    cs = CubicSpline(x, profile)
    #smooth_profile = cs(x)  # 插值后的平滑曲线

    # 高分辨率插值（放大 10 倍）
    x_dense = np.linspace(0, len(profile) - 1, len(profile) * 10)
    smooth_dense = cs(x_dense)

    # 峰值提取（亚像素级）
    peaks_dense, _ = find_peaks(smooth_dense, prominence=8)
    peak_positions = x_dense[peaks_dense]     # 亚像素位置
    peak_values = smooth_dense[peaks_dense]

    # peaks, _ = find_peaks(smooth_profile, prominence=5)
    # peak_values = profile[peaks]  # 从原始profile中取值
    plt.figure()
    plt.plot(x, profile, label='原始列平均灰度')
    plt.plot(x_dense, smooth_dense, label='三次样条插值', linestyle='--')
    plt.plot(peak_positions, peak_values, 'ro', label='峰值')
    plt.xlabel(x_label)
    plt.ylabel("灰度平均值")
    plt.title(f"自动方向（{axis.upper()}）分析的灰度曲线")
    plt.legend()
    plt.tight_layout()
    plt.show()  # 在这里添加

    return {
        'axis': axis,
        'x': x,
        'gray': gray,
        'profile': profile,
        'smooth_profile': smooth_dense,
        'peaks': peak_positions,
        'peak_values': peak_values,
    }





def fit_roi_data_direct(roi):
    print("Inside fit_roi_data_direct")

    if roi.size == 0:
        print("空的ROI区域")
        return None

    gray = cv2.cvtColor(roi, cv2.COLOR_BGR2GRAY)
    h, w = gray.shape

    if w >= h * 1.5:
        axis = 'col'
        profile = np.mean(gray, axis=0)
    # elif h >= w * 1.5:
    #     axis = 'row'
    #     profile = np.mean(gray, axis=1)
    elif h >= w * 1.2:
        axis = 'row'   # ROI 高远大于宽 → 横向分析
        #profile = np.mean(gray, axis=1)
        #x_label = "像素行位置 (y)"

        # 先对每列求平均
        col_means = np.mean(gray, axis=0)
        #找到最亮列
        peak_col = int(np.argmax(col_means))
        # 取该列 ±2 共5列，注意边界
        start_col = max(0, peak_col - 2)
        end_col = min(w, peak_col + 3)  # 右边是闭区间
        selected = gray[:, start_col:end_col]

        # step 4: 对这5列做行方向平均
        profile = np.mean(selected, axis=1)

        x_label = "像素行位置 (y)"
    else:
        axis = 'col'
        profile = np.mean(gray, axis=0)

        #三次样条
    x = np.arange(len(profile))
    cs = CubicSpline(x, profile)
    #smooth_profile = cs(x)  # 插值后的平滑曲线

    # 高分辨率插值（放大 10 倍）
    x_dense = np.linspace(0, len(profile) - 1, len(profile) * 10)
    smooth_dense = cs(x_dense)

    # 峰值提取（亚像素级）
    peaks_dense, _ = find_peaks(smooth_dense, prominence=8)
    peak_positions = x_dense[peaks_dense]     # 亚像素位置
    peak_values = smooth_dense[peaks_dense]



    return {
        'axis': axis,
        'x': x,
        'gray': gray,
        'profile': profile,
        'smooth_profile': smooth_dense,
        'peaks': peak_positions,
        'peak_values': peak_values,
    }
