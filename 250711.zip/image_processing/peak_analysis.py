import numpy as np
from image_processing.calculate import calculate_theta,calculate_a
#from image_processing.calculate import equation_sigma_with_d
#from image_processing.gaussian import asymmetric_gaussian_fwhm
from scipy.optimize import curve_fit
import config
from scipy.optimize import fsolve
from image_processing.fwhm_analysis import compute_fwhm_and_sigma

def gaussian(x, a, x0, sigma, offset):
    return a * np.exp(-(x - x0) ** 2 / (2 * sigma ** 2)) + offset

def calculate_peak_distance(peaks, peak_values,profile,use_gaussian=True):        
    #h, w = profile.shape
    if len(peaks) == 1 and peak_values> 40:
        peak_x = int(peaks[0])
        # fwhm_l, fwhm_r, sigma = compute_fwhm_and_sigma(
        #     profile, peak_x, use_gaussian=use_gaussian, plot=not use_gaussian
        # )
        # fwhm_l,fwhm_r=asymmetric_gaussian_fwhm(profile,peak_x)

        # c1=config.screen_ture_length*fwhm_l/config.screen_length
        # c2=config.screen_ture_length*fwhm_r/config.screen_length
        # print(f"[DEBUG] 左侧 FWHM: {c1:.4f}, 右侧 FWHM: {c2:.4f}")

        # from image_processing.calculate import solve_sigma
        # sigma=solve_sigma(c1,c2,config.theta_temp,config.k,config.d_temp,config.sigma_0)

        # print(f"[DEBUG] 计算得到的 σ 值为: {sigma:.6f}")

        # return (fwhm_l, fwhm_r, sigma)
        fwhm_l, fwhm_r, c_ratio , sigma = compute_fwhm_and_sigma(
            profile, peak_x,
            use_gaussian=True,
            plot=True,
            use_threshold=True,
            #threshold_fraction=0.7
        )
        print(f"[DEBUG] 模式: {'gaussian' if use_gaussian else 'direct'}")
        print(f"[DEBUG] FWHM 左={fwhm_l:.2f}, 右={fwhm_r:.2f}")
        print(f"[DEBUG] c1/c2值为: {c_ratio:.6f}")
        print(f"[DEBUG] σ 值为: {sigma:.6f}")

        return (fwhm_l, fwhm_r, sigma)
    
    elif len(peaks) == 2 :
        # 处理两个峰，计算第一个和第二个峰之间的横坐标距离
        peak1_x = peaks[0]
        peak2_x = peaks[1]
        distance = abs(peak2_x - peak1_x)
        print(f"Distance between first and second peak: {distance}")
        D=distance
        theta = calculate_theta(D)
        config.theta_temp=theta
        print(f"The calculated angle θ is: {theta} degrees")
        return distance

    elif len(peaks) == 3:
        # 处理三个峰，计算第一个和第三个峰之间的横坐标距离
        peak1_x = peaks[0]
        peak3_x = peaks[2]
        distance = abs(peak3_x - peak1_x)
        print(f"Distance between first and third peak: {distance}")
        c=distance/2
        a=calculate_a(c)
        print(f"晶格常数: {a}")
        return distance
    
    elif len(peaks) == 4:
        # 处理四个峰，计算第一个和第四个峰之间的横坐标距离
        peak1_x = peaks[0]
        peak4_x = peaks[3]
        distance = abs(peak4_x - peak1_x)
        print(f"Distance between first and forth peak: {distance}")
        c=distance/2
        a=calculate_a(c)
        print(f"晶格常数: {a}")
        return distance

    else:
        print("Unexpected number of peaks.")
        return None

