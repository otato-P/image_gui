
from image_processing.gaussian import asymmetric_gaussian_fwhm
from image_processing.direct_fwhm import estimate_fwhm_geometrically
from scipy.optimize import fsolve
#from image_processing.calculate import equation_sigma_with_d
import config
from image_processing.calculate import solve_sigma
#from image_processing.gaussian import gaussian_threshold_fit

# def compute_fwhm_and_sigma(profile, peak_x, use_gaussian=True, plot=False):
#     if use_gaussian:
#         #fwhm_l, fwhm_r = asymmetric_gaussian_fwhm(profile, peak_x)
#         fwhm_l, fwhm_r ,sigma= gaussian_threshold_fit(profile, peak_x)
#     else:
#         #fwhm_l, fwhm_r = estimate_fwhm_geometrically(profile, peak_x)
#         fwhm_l, fwhm_r, baseline, y_spline, y_adjusted, half_max = estimate_fwhm_geometrically(profile, peak_x)
#         # if plot:
#         #     plot_direct_fwhm(profile, peak_x, fwhm_l, fwhm_r)
#         if plot:
#             plot_direct_fwhm(profile, peak_x, fwhm_l, fwhm_r, baseline, y_spline, y_adjusted, half_max)


def compute_fwhm_and_sigma(profile, peak_x, use_gaussian=True, plot=False, use_threshold=False):
    if use_gaussian and not use_threshold:
        from image_processing.gaussian import asymmetric_gaussian_fwhm
        fwhm_l, fwhm_r = asymmetric_gaussian_fwhm(profile, peak_x)
    # elif use_gaussian and use_threshold:
    #     fwhm_l, fwhm_r, sigma = gaussian_threshold_fit(profile, fraction=threshold_fraction, plot=plot)
    #     # 直接返回，不再重复计算 sigma
    #     return fwhm_l, fwhm_r, sigma
    else:
        from image_processing.direct_fwhm import estimate_fwhm_geometrically
        fwhm_l, fwhm_r = estimate_fwhm_geometrically(profile, peak_x)
        # if plot:
        #     from image_processing.direct_fwhm import plot_direct_fwhm
        #     plot_direct_fwhm(profile, peak_x, fwhm_l, fwhm_r, )

    # 后处理：单位换算 & σ 求解（仅非 threshold 模式）
    c1 = config.screen_ture_length * fwhm_l / config.screen_length
    c2 = config.screen_ture_length * fwhm_r / config.screen_length
    
    c_ratio=c1/c2
    try:
        from image_processing.calculate import solve_sigma  
        sigma = solve_sigma(c1, c2, config.k, config.theta_temp, config.sigma_0)
    except Exception as e:
        print(f"[σ求解失败]: {e}")
        sigma = 0

    return fwhm_l, fwhm_r, c_ratio,sigma


    # # 单位换算
    # c1 = config.screen_ture_length * fwhm_l / config.screen_length
    # c2 = config.screen_ture_length * fwhm_r / config.screen_length
    # print(f"左侧 FWHM: {c1:.4f}")
    # print(f"右侧 FWHM: {c2:.4f}")

    # # 解 sigma
    # sigma_initial_guess = 0.5
    # sigma = fsolve(
    #     equation_sigma, sigma_initial_guess,
    #     args=(c1, c2, config.theta_temp, config.k, config.d_temp)
    # )[0]
    # print(f"计算得到的 σ 值是: {sigma:.6f}")

    # return fwhm_l, fwhm_r, sigma
        # ✅ 单位换算
    # try:
    #     c1 = config.screen_ture_length * fwhm_l / config.screen_length
    #     c2 = config.screen_ture_length * fwhm_r / config.screen_length
    #     print(f"左侧 FWHM: {c1:.4f}")
    #     print(f"右侧 FWHM: {c2:.4f}")

    #     # 解 sigma
    #     sigma_initial_guess = 0.5
    #     sigma = fsolve(
    #         equation_sigma, sigma_initial_guess,
    #         args=(c1, c2, config.theta_temp, config.k, config.d_temp)
    #     )[0]
    #     print(f"计算得到的 σ 值是: {sigma:.6f}")
    # except Exception as e:
    #     print("⚠️ σ 计算失败:", e)
    #     sigma = 0

    c1 = config.screen_ture_length * fwhm_l / config.screen_length
    c2 = config.screen_ture_length * fwhm_r / config.screen_length
    print(f"左侧 FWHM: {c1:.4f}")
    print(f"右侧 FWHM: {c2:.4f}")
    # 假设你已计算出 c1, c2
    # try:
        
    #     sigma = solve_sigma(c1, c2, config.theta_temp, config.k, config.d_temp,config.sigma_0)
    #     print(f"计算得到的 σ 值是: {sigma:.6f}")
    # except ValueError as e:
    #     print(e)
    #     sigma = 0
        # 使用新的稳定求解方法 solve_sigma（内部用的是 log 形式）
    try:
        from image_processing.calculate import solve_sigma  
        #sigma = solve_sigma(c1, c2, config.theta_temp, config.k, config.d_temp, config.sigma_0)
        sigma = solve_sigma(c1, c2, config.k, config.theta_temp,config.sigma_0)
        print(f"计算得到的 σ 值是: {sigma:.6f}")
    except Exception as e:
        print(f"[σ求解失败]: {e}")
        sigma = 0

    return fwhm_l, fwhm_r, sigma


    return fwhm_l, fwhm_r, sigma

#from image_processing.gaussian import asymmetric_gaussian_fwhm

def calculate_fwhm_from_profile(profile, peaks,use_gaussian=True):
    if len(peaks) < 1:
        print("没有峰值，无法计算 FWHM")
        return None

    peak_x = int(peaks[0])  # 默认取第一个峰

    #fwhm_l, fwhm_r = asymmetric_gaussian_fwhm(profile, peak_x)
    if use_gaussian:
        from image_processing.gaussian import asymmetric_gaussian_fwhm
        fwhm_l, fwhm_r = asymmetric_gaussian_fwhm(profile, ratio=0.6)
    else:
        from image_processing.direct_fwhm import estimate_fwhm_geometrically, plot_direct_fwhm
        fwhm_l, fwhm_r = estimate_fwhm_geometrically(profile, peak_x)
        plot_direct_fwhm(profile, peak_x, fwhm_l, fwhm_r)


        
    #fwhm_l=fwhm_l*config.screen_ture_length/config.screen_length
    #fwhm_r=fwhm_r*config.screen_ture_length/config.screen_length
    fwhm_avg = (fwhm_l + fwhm_r) / 2 if (fwhm_l > 0 and fwhm_r > 0) else max(fwhm_l, fwhm_r)

    #print(f"[自定义FWHM] 左={fwhm_l:.2f}, 右={fwhm_r:.2f}, 平均={fwhm_avg:.2f}")
    print(f"[{'高斯' if use_gaussian else '几何'}FWHM] 左={fwhm_l:.2f}, 右={fwhm_r:.2f}, 平均={fwhm_avg:.2f}")
    return fwhm_avg

