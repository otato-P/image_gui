# 全局变量配置
screen_length=None
part_tan_theta = None
screen_ture_length=58
screen_sample_length=154.7
d_temp=0.18527
k=73.733
theta_temp=0
sigma_0=1.77
c1_sample=1.63
c2_sample=1.07
ratio=0.6
